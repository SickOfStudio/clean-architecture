﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory
{
	using ValidatableResponse = io.restassured.response.ValidatableResponse;
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using BaseComponentTest = io.wkrzywiec.hexagonal.library.domain.BaseComponentTest;
	using AddNewBookCommand = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.AddNewBookCommand;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using HttpStatus = org.springframework.http.HttpStatus;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static io.restassured.RestAssured.given;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.hamcrest.Matchers.greaterThan;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

	public class AddNewBookComponentTest : BaseComponentTest
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Search for a new book in Google Books") public void whenSearchForBook_thenGetList()
		public virtual void whenSearchForBook_thenGetList()
		{
			//when
			ValidatableResponse response = given().when().param("query", "lean startup").get(baseURL + "/google/books").prettyPeek().then();

			//then
			response.statusCode(HttpStatus.OK.value()).contentType("application/json").body("items.size()", greaterThan(0));
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Add new book to a database & make it available") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenGoogleBooId_whenAddNewBook_thenBookIsSaved()
		public virtual void givenGoogleBooId_whenAddNewBook_thenBookIsSaved()
		{
			//given
			AddNewBookCommand addNewBookCommand = AddNewBookCommand.builder().googleBookId(BookTestData.homoDeusBookGoogleId()).build();

			//when
			given().contentType("application/json").body(addNewBookCommand).when().post(baseURL + "/books").prettyPeek().then();

			//then
			long? savedBookId = databaseHelper.HomoDeusBookId;
			assertTrue(savedBookId > 0);

			long? availableBookId = databaseHelper.getPrimaryKeyOfAvailableByBookBy(savedBookId);

			assertTrue(availableBookId > 0);
		}
	}

}