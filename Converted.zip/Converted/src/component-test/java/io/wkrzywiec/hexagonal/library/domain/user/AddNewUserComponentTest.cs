﻿namespace io.wkrzywiec.hexagonal.library.domain.user
{
	using BaseComponentTest = io.wkrzywiec.hexagonal.library.domain.BaseComponentTest;
	using AddUserCommand = io.wkrzywiec.hexagonal.library.domain.user.core.model.AddUserCommand;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static io.restassured.RestAssured.given;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

	public class AddNewUserComponentTest : BaseComponentTest
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Create new user") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldCreateNewUser()
		public virtual void shouldCreateNewUser()
		{
			//given
			AddUserCommand addUserCommand = AddUserCommand.builder().firstName("John").lastName("Doe").email("john.doe@test.com").build();

			//when
			given().contentType("application/json").body(addUserCommand).when().post(baseURL + "/users").prettyPeek().then();

			//then
			long? savedUserId = databaseHelper.JohnDoeUserId;
			assertTrue(savedUserId > 0);
		}

	}

}