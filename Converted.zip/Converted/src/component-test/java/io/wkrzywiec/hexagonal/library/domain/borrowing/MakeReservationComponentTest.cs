﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using BaseComponentTest = io.wkrzywiec.hexagonal.library.domain.BaseComponentTest;
	using BookStatus = io.wkrzywiec.hexagonal.library.domain.borrowing.application.model.BookStatus;
	using ChangeBookStatusRequest = io.wkrzywiec.hexagonal.library.domain.borrowing.application.model.ChangeBookStatusRequest;
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;
	using BookRepository = io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.BookRepository;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static io.restassured.RestAssured.given;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

	public class MakeReservationComponentTest : BaseComponentTest
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.BookRepository bookRepository;
		private BookRepository bookRepository;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Reserve available book") @Sql({"/book-and-user.sql", "/available-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenBookIsAvailable_thenMakeReservation_thenBookIsReserved()
		public virtual void givenBookIsAvailable_thenMakeReservation_thenBookIsReserved()
		{
			//given
			long? homoDeusBookId = databaseHelper.HomoDeusBookId;
			long? activeUserId = databaseHelper.JohnDoeUserId;

			ChangeBookStatusRequest reservationRequest = ChangeBookStatusRequest.builder().userId(activeUserId).status(BookStatus.RESERVED).build();

			//when
			given().contentType("application/json").body(reservationRequest).when().patch(baseURL + "/books/" + homoDeusBookId + "/status").prettyPeek().then();

			long? reservationId = databaseHelper.getPrimaryKeyOfReservationByBookId(homoDeusBookId);
			assertTrue(reservationId > 0);
		}
	}

}