﻿namespace io.wkrzywiec.hexagonal.library.domain
{
	using RestAssured = io.restassured.RestAssured;
	using DatabaseHelper = io.wkrzywiec.hexagonal.library.DatabaseHelper;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using SpringBootTest = org.springframework.boot.test.context.SpringBootTest;
	using LocalServerPort = org.springframework.boot.web.server.LocalServerPort;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) public abstract class BaseComponentTest
	public abstract class BaseComponentTest
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @LocalServerPort private int port;
		private int port;
		protected internal string baseURL;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired protected org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
		protected internal JdbcTemplate jdbcTemplate;
		protected internal DatabaseHelper databaseHelper;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			this.baseURL = "http://localhost:" + port;
			RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
			databaseHelper = new DatabaseHelper(jdbcTemplate);
		}
	}

}