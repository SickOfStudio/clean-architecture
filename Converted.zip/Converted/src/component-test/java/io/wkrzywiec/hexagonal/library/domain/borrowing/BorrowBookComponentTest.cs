﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using BaseComponentTest = io.wkrzywiec.hexagonal.library.domain.BaseComponentTest;
	using BookStatus = io.wkrzywiec.hexagonal.library.domain.borrowing.application.model.BookStatus;
	using ChangeBookStatusRequest = io.wkrzywiec.hexagonal.library.domain.borrowing.application.model.ChangeBookStatusRequest;
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static io.restassured.RestAssured.given;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

	public class BorrowBookComponentTest : BaseComponentTest
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Borrow reserved book") @Sql({"/book-and-user.sql", "/reserved-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenBookIsReserved_thenBorrowIt_thenBookIsBorrowed()
		public virtual void givenBookIsReserved_thenBorrowIt_thenBookIsBorrowed()
		{
			//given
			long? homoDeusBookId = databaseHelper.HomoDeusBookId;
			long? activeUserId = databaseHelper.JohnDoeUserId;

			ChangeBookStatusRequest borrowRequest = ChangeBookStatusRequest.builder().userId(activeUserId).status(BookStatus.BORROWED).build();

			//when
			given().contentType("application/json").body(borrowRequest).when().patch(baseURL + "/books/" + homoDeusBookId + "/status").prettyPeek().then();

			long? borrowId = databaseHelper.getPrimaryKeyOfBorrowedByBookId(homoDeusBookId);
			assertTrue(borrowId > 0);
		}
	}

}