﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using CrudRepository = org.springframework.data.repository.CrudRepository;
	using Repository = org.springframework.stereotype.Repository;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Repository public interface BookRepository extends org.springframework.data.repository.CrudRepository<io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book, long>
	public interface BookRepository : CrudRepository<Book, long>
	{
	}

}