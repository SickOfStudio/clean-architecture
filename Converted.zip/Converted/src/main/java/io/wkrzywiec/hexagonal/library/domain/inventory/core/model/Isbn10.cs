﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode @Embeddable public class Isbn10
	public class Isbn10
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="isbn_10") private String value;
		private string value;

		public Isbn10(string value)
		{
			if (value.matches("\\d{10}"))
			{
				this.value = value;
			}
			else
			{
				throw new System.ArgumentException("ISBN-10 should have 10 digits only.");
			}
		}

		private Isbn10()
		{
		}

		public virtual string AsString
		{
			get
			{
				return value;
			}
		}
	}

}