﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;



//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Entity @Table(name="book") @EqualsAndHashCode public class Book
	public class Book
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Id @GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY) private System.Nullable<long> id;
		private long? id;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embedded private BookIdentification identification;
		private BookIdentification identification;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="title") private String title;
		private string title;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ManyToMany(fetch = javax.persistence.FetchType.EAGER, cascade= {javax.persistence.CascadeType.DETACH, javax.persistence.CascadeType.MERGE, javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.REFRESH}) @JoinTable(name="book_author", joinColumns=@JoinColumn(name="book_id"), inverseJoinColumns=@JoinColumn(name="author_id")) private java.util.Set<Author> authors;
		private ISet<Author> authors;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="publisher") private String publisher;
		private string publisher;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="publishedDate") private String publishedDate;
		private string publishedDate;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="description", columnDefinition="TEXT") private String description;
		private string description;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="page_count") private int pages;
		private int pages;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="imageLink", columnDefinition="TEXT") @EqualsAndHashCode.Exclude private String imageLink;
		private string imageLink;

		public Book(BookIdentification identification, string title, ISet<Author> authors, string publisher, string publishedDate, string description, int pages, string imageLink)
		{
			this.identification = identification;
			this.title = title;
			this.authors = authors;
			this.publisher = publisher;
			this.publishedDate = publishedDate;
			this.description = description;
			this.pages = pages;
			this.imageLink = imageLink;
		}

		public virtual long? IdAsLong
		{
			get
			{
				return id;
			}
		}

		private Book()
		{
		}
	}

}