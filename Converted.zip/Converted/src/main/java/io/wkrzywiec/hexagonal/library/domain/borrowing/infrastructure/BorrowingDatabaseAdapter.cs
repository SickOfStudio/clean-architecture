﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure
{
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using OverdueReservationEntity = io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.entity.OverdueReservationEntity;
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using DueDate = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.DueDate;
	using OverdueReservation = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.OverdueReservation;
	using ReservationDetails = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationDetails;
	using ReservationId = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationId;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using BorrowingDatabase = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase;
	using BorrowedBookRowMapper = io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.mapper.BorrowedBookRowMapper;
	using ReservedBookRowMapper = io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.mapper.ReservedBookRowMapper;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using DataAccessException = org.springframework.dao.DataAccessException;
	using BeanPropertyRowMapper = org.springframework.jdbc.core.BeanPropertyRowMapper;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class BorrowingDatabaseAdapter implements io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase
	public class BorrowingDatabaseAdapter : BorrowingDatabase
	{

		private readonly JdbcTemplate jdbcTemplate;

		public virtual void save(AvailableBook availableBook)
		{
			jdbcTemplate.update("INSERT INTO available (book_id) VALUES (?)", availableBook.IdAsLong);

			jdbcTemplate.update("DELETE FROM reserved WHERE book_id = ?", availableBook.IdAsLong);

			jdbcTemplate.update("DELETE FROM borrowed WHERE book_id = ?", availableBook.IdAsLong);
		}

		public virtual Optional<AvailableBook> getAvailableBook(long? bookId)
		{
			try
			{
				return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT book_id FROM available WHERE book_id = ?", typeof(AvailableBook), bookId));
			}
			catch (DataAccessException)
			{
				return null;
			}
		}

		public virtual Optional<ActiveUser> getActiveUser(long? userId)
		{
			try
			{
				jdbcTemplate.queryForObject("SELECT id FROM public.library_user as u WHERE u.id = ?", typeof(Long), userId);
			}
			catch (DataAccessException)
			{
				return null;
			}

			IList<ReservedBook> reservedBooksByUser = getReservedBooksByUser(userId);
			IList<BorrowedBook> borrowedBooksByUser = getBorrowedBooksByUser(userId);
			return (new ActiveUser(userId, reservedBooksByUser, borrowedBooksByUser));
		}

		public virtual ReservationDetails save(ReservedBook reservedBook)
		{
		   jdbcTemplate.update("INSERT INTO reserved (book_id, user_id, reserved_date) VALUES (?, ?, ?)", reservedBook.IdAsLong, reservedBook.AssignedUserIdAsLong, Timestamp.from(reservedBook.ReservedDateAsInstant));

			jdbcTemplate.update("DELETE FROM available WHERE book_id = ?", reservedBook.IdAsLong);

		   ReservationId reservationId = jdbcTemplate.queryForObject("SELECT id FROM reserved WHERE book_id = ?", typeof(ReservationId), reservedBook.IdAsLong);
		   return new ReservationDetails(reservationId, reservedBook);
		}

		public virtual void save(BorrowedBook borrowedBook)
		{
			jdbcTemplate.update("INSERT INTO borrowed (book_id, user_id, borrowed_date) VALUES (?, ?, ?)", borrowedBook.IdAsLong, borrowedBook.AssignedUserIdAsLong, Timestamp.from(borrowedBook.BorrowedDateAsInstant));

			jdbcTemplate.update("DELETE FROM reserved WHERE book_id = ?", borrowedBook.IdAsLong);

			jdbcTemplate.update("DELETE FROM available WHERE book_id = ?", borrowedBook.IdAsLong);

		}

		public virtual IList<OverdueReservation> findReservationsForMoreThan(long? days)
		{
			IList<OverdueReservationEntity> entities = jdbcTemplate.query("SELECT id AS reservationId, book_id AS bookIdentification FROM reserved WHERE DATEADD(day, ?, reserved_date) > NOW()", new BeanPropertyRowMapper<OverdueReservationEntity>(typeof(OverdueReservationEntity)), days);
			return entities.Select(entity => new OverdueReservation(entity.ReservationId, entity.BookIdentification)).ToList();
		}

		public virtual Optional<ReservedBook> getReservedBook(long? bookId)
		{
			try
			{
				return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT book_id, user_id, reserved_date FROM reserved WHERE book_id = ?", new ReservedBookRowMapper(), bookId));
			}
			catch (DataAccessException)
			{
				return null;
			}
		}

		public virtual Optional<BorrowedBook> getBorrowedBook(long? bookId)
		{
			try
			{
				return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT book_id, user_id, borrowed_date FROM borrowed WHERE book_id = ?", new BorrowedBookRowMapper(), bookId));
			}
			catch (DataAccessException)
			{
				return null;
			}
		}

		private IList<ReservedBook> getReservedBooksByUser(long? userId)
		{
			try
			{
				return jdbcTemplate.query("SELECT book_id, user_id, reserved_date FROM reserved WHERE user_id = ?", new ReservedBookRowMapper(), userId);
			}
			catch (DataAccessException)
			{
				return new List<ReservedBook>();
			}
		}

		private IList<BorrowedBook> getBorrowedBooksByUser(long? userId)
		{
			try
			{
				return jdbcTemplate.query("SELECT book_id, user_id, borrowed_date FROM borrowed WHERE user_id = ?", new BorrowedBookRowMapper(), userId);
			}
			catch (DataAccessException)
			{
				return new List<BorrowedBook>();
			}
		}
	}

}