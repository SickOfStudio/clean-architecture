﻿namespace io.wkrzywiec.hexagonal.library.infrastructure
{
	using BorrowingFacade = io.wkrzywiec.hexagonal.library.domain.borrowing.core.BorrowingFacade;
	using BorrowBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.BorrowBook;
	using CancelOverdueReservations = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.CancelOverdueReservations;
	using GiveBackBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.GiveBackBook;
	using MakeBookAvailable = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.MakeBookAvailable;
	using ReserveBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.ReserveBook;
	using BorrowingDatabase = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase;
	using BorrowingEventPublisher = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher;
	using BorrowingDatabaseAdapter = io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.BorrowingDatabaseAdapter;
	using SpringBorrowingEventPublisherAdapter = io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.SpringBorrowingEventPublisherAdapter;
	using Qualifier = org.springframework.beans.factory.annotation.Qualifier;
	using ApplicationEventPublisher = org.springframework.context.ApplicationEventPublisher;
	using Bean = org.springframework.context.annotation.Bean;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;

	public class BorrowingDomainConfig
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase borrowingDatabase(org.springframework.jdbc.core.JdbcTemplate jdbcTemplate)
		public virtual BorrowingDatabase borrowingDatabase(JdbcTemplate jdbcTemplate)
		{
			return new BorrowingDatabaseAdapter(jdbcTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher(org.springframework.context.ApplicationEventPublisher applicationEventPublisher)
		public virtual BorrowingEventPublisher borrowingEventPublisher(ApplicationEventPublisher applicationEventPublisher)
		{
			return new SpringBorrowingEventPublisherAdapter(applicationEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean @Qualifier("MakeBookAvailable") public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.MakeBookAvailable makeBookAvailable(io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase database, io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher)
		public virtual MakeBookAvailable makeBookAvailable(BorrowingDatabase database, BorrowingEventPublisher borrowingEventPublisher)
		{
			return new BorrowingFacade(database, borrowingEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean @Qualifier("ReserveBook") public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.ReserveBook reserveBook(io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase database, io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher)
		public virtual ReserveBook reserveBook(BorrowingDatabase database, BorrowingEventPublisher borrowingEventPublisher)
		{
			return new BorrowingFacade(database, borrowingEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean @Qualifier("BorrowBook") public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.BorrowBook borrowBook(io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase database, io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher)
		public virtual BorrowBook borrowBook(BorrowingDatabase database, BorrowingEventPublisher borrowingEventPublisher)
		{
			return new BorrowingFacade(database, borrowingEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean @Qualifier("GiveBackBook") public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.GiveBackBook giveBackBook(io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase database, io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher)
		public virtual GiveBackBook giveBackBook(BorrowingDatabase database, BorrowingEventPublisher borrowingEventPublisher)
		{
			return new BorrowingFacade(database, borrowingEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean @Qualifier("CancelOverdueReservations") public io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.CancelOverdueReservations cancelOverdueReservations(io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase database, io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher borrowingEventPublisher)
		public virtual CancelOverdueReservations cancelOverdueReservations(BorrowingDatabase database, BorrowingEventPublisher borrowingEventPublisher)
		{
			return new BorrowingFacade(database, borrowingEventPublisher);
		}
	}

}