﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming
{
	using SendReservationConfirmationCommand = io.wkrzywiec.hexagonal.library.domain.email.core.model.SendReservationConfirmationCommand;

	public interface SendReservationConfirmation
	{
		void handle(SendReservationConfirmationCommand reservationConfirmationCommand);
	}

}