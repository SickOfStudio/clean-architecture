﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.application
{
	using MakeBookAvailableCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.MakeBookAvailableCommand;
	using MakeBookAvailable = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.MakeBookAvailable;
	using NewBookWasAddedEvent = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using Qualifier = org.springframework.beans.factory.annotation.Qualifier;
	using EventListener = org.springframework.context.@event.EventListener;
	using Component = org.springframework.stereotype.Component;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor @Component public class NewBookWasAddedEventHandler
	public class NewBookWasAddedEventHandler
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Qualifier("MakeBookAvailable") private final io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.MakeBookAvailable makeBookAvailable;
		private readonly MakeBookAvailable makeBookAvailable;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EventListener public void handle(io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent event)
		public virtual void handle(NewBookWasAddedEvent @event)
		{
			makeBookAvailable.handle(new MakeBookAvailableCommand(@event.BookIdAsLong));
		}
	}

}