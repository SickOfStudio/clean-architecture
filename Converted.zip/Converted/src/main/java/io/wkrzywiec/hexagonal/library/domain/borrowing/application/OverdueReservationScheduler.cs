﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.application
{
	using CancelOverdueReservations = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.CancelOverdueReservations;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using Qualifier = org.springframework.beans.factory.annotation.Qualifier;
	using Scheduled = org.springframework.scheduling.annotation.Scheduled;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class OverdueReservationScheduler
	public class OverdueReservationScheduler
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Qualifier("CancelOverdueReservations") private final io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.CancelOverdueReservations overdueReservations;
		private readonly CancelOverdueReservations overdueReservations;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Scheduled(fixedRate = 60 * 1000) public void checkOverdueReservations()
		public virtual void checkOverdueReservations()
		{
			overdueReservations.cancelOverdueReservations();
		}
	}

}