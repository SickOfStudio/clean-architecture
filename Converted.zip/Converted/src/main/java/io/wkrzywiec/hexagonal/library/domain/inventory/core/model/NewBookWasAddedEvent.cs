﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{

	public class NewBookWasAddedEvent
	{

		private readonly long? bookId;
		private readonly Instant timestamp;

		public NewBookWasAddedEvent(long? bookId)
		{
			this.bookId = bookId;
			timestamp = Instant.now();
		}

		public virtual long? BookIdAsLong
		{
			get
			{
				return bookId;
			}
		}

		public virtual string EventTimeStampAsString
		{
			get
			{
				return timestamp.ToString();
			}
		}
	}

}