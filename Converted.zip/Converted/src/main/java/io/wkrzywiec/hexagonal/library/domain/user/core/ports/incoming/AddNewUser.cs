﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming
{
	using AddUserCommand = io.wkrzywiec.hexagonal.library.domain.user.core.model.AddUserCommand;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;

	public interface AddNewUser
	{
		UserIdentifier handle(AddUserCommand addUserCommand);
	}

}