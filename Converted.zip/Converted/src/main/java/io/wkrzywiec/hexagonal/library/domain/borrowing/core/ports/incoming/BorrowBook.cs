﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming
{
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;

	public interface BorrowBook
	{
		void handle(BorrowBookCommand borrowBookCommand);
	}

}