﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.incoming
{
	using AddNewBookCommand = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.AddNewBookCommand;

	public interface AddNewBook
	{
		void handle(AddNewBookCommand addNewBookCommand);
	}

}