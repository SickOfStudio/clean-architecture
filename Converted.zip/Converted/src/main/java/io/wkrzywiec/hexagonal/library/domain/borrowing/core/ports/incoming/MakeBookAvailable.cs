﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming
{
	using MakeBookAvailableCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.MakeBookAvailableCommand;

	public interface MakeBookAvailable
	{
		void handle(MakeBookAvailableCommand bookAvailableCommand);
	}

}