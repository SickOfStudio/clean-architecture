﻿namespace io.wkrzywiec.hexagonal.library.domain.email.infrastructure
{
	using EmailDatabase = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using DataAccessException = org.springframework.dao.DataAccessException;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class EmailDatabaseAdapter implements io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase
	public class EmailDatabaseAdapter : EmailDatabase
	{

		private readonly JdbcTemplate jdbcTemplate;

		public virtual Optional<string> getTitleByBookId(long? bookId)
		{
			try
			{
				return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT title FROM book WHERE id = ?", typeof(string), bookId));
			}
			catch (DataAccessException)
			{
				return null;
			}
		}

		public virtual Optional<string> getUserEmailAddress(long? userId)
		{
			try
			{
				return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT email FROM library_user WHERE id = ?", typeof(string), userId));
			}
			catch (DataAccessException)
			{
				return null;
			}
		}
	}

}