﻿namespace io.wkrzywiec.hexagonal.library.domain.email.application
{
	using BookReservedEvent = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent;
	using SendReservationConfirmationCommand = io.wkrzywiec.hexagonal.library.domain.email.core.model.SendReservationConfirmationCommand;
	using SendReservationConfirmation = io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming.SendReservationConfirmation;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using EventListener = org.springframework.context.@event.EventListener;
	using Component = org.springframework.stereotype.Component;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Component @RequiredArgsConstructor public class BookReservedEventHandler
	public class BookReservedEventHandler
	{

		private readonly SendReservationConfirmation sendReservationConfirmation;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EventListener public void handle(io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent event)
		public virtual void handle(BookReservedEvent @event)
		{
			sendReservationConfirmation.handle(new SendReservationConfirmationCommand(@event.ReservationIdAsLong, @event.UserIdAsLong, @event.BookIdAsLong));
		}
	}

}