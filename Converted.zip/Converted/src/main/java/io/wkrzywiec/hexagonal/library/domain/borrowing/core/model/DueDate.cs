﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	using AllArgsConstructor = lombok.AllArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AllArgsConstructor public class DueDate
	public class DueDate
	{
		private readonly Instant timeStamp;

		public virtual Instant asInstant()
		{
			return timeStamp;
		}
	}

}