﻿namespace io.wkrzywiec.hexagonal.library.infrastructure
{
	using UserFacade = io.wkrzywiec.hexagonal.library.domain.user.core.UserFacade;
	using UserDatabaseAdapter = io.wkrzywiec.hexagonal.library.domain.user.infrastructure.UserDatabaseAdapter;
	using UserRepository = io.wkrzywiec.hexagonal.library.domain.user.infrastructure.UserRepository;
	using AddNewUser = io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming.AddNewUser;
	using UserDatabase = io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase;
	using Bean = org.springframework.context.annotation.Bean;

	public class UserDomainConfig
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase userDatabase(io.wkrzywiec.hexagonal.library.domain.user.infrastructure.UserRepository userRepository)
		public virtual UserDatabase userDatabase(UserRepository userRepository)
		{
			return new UserDatabaseAdapter(userRepository);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming.AddNewUser addNewUser(io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase userDatabase)
		public virtual AddNewUser addNewUser(UserDatabase userDatabase)
		{
			return new UserFacade(userDatabase);
		}
	}

}