﻿namespace io.wkrzywiec.hexagonal.library.query
{
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using HttpStatus = org.springframework.http.HttpStatus;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using org.springframework.web.bind.annotation;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RestController @RequestMapping("/google/books") @RequiredArgsConstructor public class GoogleBooksSearchController
	public class GoogleBooksSearchController
	{

		private readonly GoogleBookSearchClient client;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @GetMapping(value = "", produces = "application/json") public org.springframework.http.ResponseEntity<String> searchForBooks(@RequestParam String query)
		public virtual ResponseEntity<string> searchForBooks(string query)
		{
			return new ResponseEntity<string>(client.searchForBooks(query), HttpStatus.OK);
		}
	}

}