﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode @Embeddable public class Isbn13
	public class Isbn13
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="isbn_13") private String value;
		private string value;

		public Isbn13(string value)
		{
			if (value.matches("\\d{13}"))
			{
				this.value = value;
			}
			else
			{
				throw new System.ArgumentException("ISBN-13 should have 10 digits only.");
			}
		}

		private Isbn13()
		{
		}

		public virtual string AsString
		{
			get
			{
				return value;
			}
		}
	}

}