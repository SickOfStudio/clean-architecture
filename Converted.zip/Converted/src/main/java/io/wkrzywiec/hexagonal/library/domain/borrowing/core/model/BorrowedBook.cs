﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode public class BorrowedBook implements Book
	public class BorrowedBook : Book
	{

		private long? bookId;
		private long? userId;
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode.Exclude private java.time.Instant borrowedDate;
		private Instant borrowedDate;

		public BorrowedBook(long? bookId, long? userId)
		{
			this.bookId = bookId;
			this.userId = userId;
			this.borrowedDate = Instant.now();
		}

		public BorrowedBook(long? bookId, long? userId, Instant borrowedDate)
		{
			this.bookId = bookId;
			this.userId = userId;
			this.borrowedDate = borrowedDate;
		}

		public virtual long? IdAsLong
		{
			get
			{
				return bookId;
			}
		}

		public virtual long? AssignedUserIdAsLong
		{
			get
			{
				return userId;
			}
		}

		public virtual Instant BorrowedDateAsInstant
		{
			get
			{
				return borrowedDate;
			}
		}
	}

}