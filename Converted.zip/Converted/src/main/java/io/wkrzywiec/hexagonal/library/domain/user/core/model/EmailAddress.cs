﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embeddable @EqualsAndHashCode public class EmailAddress
	public class EmailAddress
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="email") private String value;
		private string value;

		public EmailAddress(string value)
		{
			Pattern pattern = Pattern.compile("^(.+)@(.+)$");
			Matcher matcher = pattern.matcher(value);
			if (matcher.matches())
			{
				this.value = value;
			}
			else
			{
				throw new System.ArgumentException("Provided value is not an email address");
			}
		}

		private EmailAddress()
		{
		}
	}

}