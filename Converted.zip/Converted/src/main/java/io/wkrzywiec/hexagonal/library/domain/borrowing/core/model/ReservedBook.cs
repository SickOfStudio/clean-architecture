﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode public class ReservedBook implements Book
	public class ReservedBook : Book
	{

		private readonly long? bookId;
		private readonly long? userId;
		private readonly Instant reservedDate;

		public ReservedBook(long? bookId, long? userId)
		{
			this.bookId = bookId;
			this.userId = userId;
			this.reservedDate = Instant.now();
		}

		public ReservedBook(long? bookId, long? userId, Instant reservedDate)
		{
			this.bookId = bookId;
			this.userId = userId;
			this.reservedDate = reservedDate;
		}

		public virtual long? IdAsLong
		{
			get
			{
				return bookId;
			}
		}

		public virtual long? AssignedUserIdAsLong
		{
			get
			{
				return userId;
			}
		}

		public virtual Instant ReservedDateAsInstant
		{
			get
			{
				return reservedDate;
			}
		}
	}

}