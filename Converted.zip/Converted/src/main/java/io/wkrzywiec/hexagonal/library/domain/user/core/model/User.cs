﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Entity @Table(name="library_user") @EqualsAndHashCode public class User
	public class User
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Id @GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY) @EqualsAndHashCode.Exclude private System.Nullable<long> id;
		private long? id;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embedded private EmailAddress emailAddress;
		private EmailAddress emailAddress;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="first_name") private String firstName;
		private string firstName;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="last_name") private String lastName;
		private string lastName;

		public User(EmailAddress emailAddress, string firstName, string lastName)
		{
			this.emailAddress = emailAddress;
			this.firstName = firstName;
			this.lastName = lastName;
		}

		public virtual long? IdentifierAsLong
		{
			get
			{
				return id;
			}
		}

		private User()
		{
		}
	}

}