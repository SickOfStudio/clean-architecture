﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.email.infrastructure
{
	using Method = com.sendgrid.Method;
	using Request = com.sendgrid.Request;
	using SendGrid = com.sendgrid.SendGrid;
	using Mail = com.sendgrid.helpers.mail.Mail;
	using Content = com.sendgrid.helpers.mail.objects.Content;
	using Email = com.sendgrid.helpers.mail.objects.Email;
	using ReservationConfirmEmail = io.wkrzywiec.hexagonal.library.domain.email.core.model.ReservationConfirmEmail;
	using EmailSender = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender;

	public class SendGridEmailSender : EmailSender
	{

		public virtual void sendReservationConfirmationEmail(ReservationConfirmEmail reservationConfirmEmail)
		{
			Email from = new Email(reservationConfirmEmail.FromEmailAddressAsString);
			Email to = new Email(reservationConfirmEmail.ToEmailAddressAsString);
			Content content = new Content("text/plain", reservationConfirmEmail.ContentAsString);
			Mail mail = new Mail(from, reservationConfirmEmail.SubjectAsString, to, content);

			SendGrid sg = new SendGrid(Environment.GetEnvironmentVariable("SENDGRID_API_KEY"));
			Request request = new Request();
			try
			{
				request.Method = Method.POST;
				request.Endpoint = "mail/send";
				request.Body = mail.build();
				sg.api(request);
			}
			catch (IOException ex)
			{
				Console.Write(ex);
			}
		}
	}

}