﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.mapper
{
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using RowMapper = org.springframework.jdbc.core.RowMapper;


	public class ReservedBookRowMapper : RowMapper<ReservedBook>
	{

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: @Override public io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook mapRow(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException
		public override ReservedBook mapRow(ResultSet rs, int rowNum)
		{
			return new ReservedBook(rs.getLong("book_id"), rs.getLong("user_id"), rs.getTimestamp("reserved_date").toInstant());
		}
	}

}