﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing
{
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using DueDate = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.DueDate;
	using OverdueReservation = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.OverdueReservation;
	using ReservationDetails = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationDetails;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;


	public interface BorrowingDatabase
	{
		void save(AvailableBook availableBook);
		ReservationDetails save(ReservedBook reservedBook);
		void save(BorrowedBook borrowedBook);
		Optional<AvailableBook> getAvailableBook(long? bookId);
		Optional<ActiveUser> getActiveUser(long? userId);
		IList<OverdueReservation> findReservationsForMoreThan(long? days);
		Optional<ReservedBook> getReservedBook(long? bookId);
		Optional<BorrowedBook> getBorrowedBook(long? bookId);
	}

}