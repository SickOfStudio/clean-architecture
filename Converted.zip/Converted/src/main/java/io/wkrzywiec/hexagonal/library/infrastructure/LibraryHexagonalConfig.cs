﻿namespace io.wkrzywiec.hexagonal.library.infrastructure
{
	using Bean = org.springframework.context.annotation.Bean;
	using RestTemplate = org.springframework.web.client.RestTemplate;

	public class LibraryHexagonalConfig
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean RestTemplate restTemplate()
		internal virtual RestTemplate restTemplate()
		{
			return new RestTemplate();
		}
	}

}