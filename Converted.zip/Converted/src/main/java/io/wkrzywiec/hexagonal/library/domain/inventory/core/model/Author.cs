﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;
	using ToString = lombok.ToString;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Entity @Table(name="author") @EqualsAndHashCode @ToString public class Author
	public class Author
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Id @GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY) @Column(name="id") private int id;
		private int id;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="name", unique=true) private String name;
		private string name;

		public Author(string name)
		{
			this.name = name;
		}

		private Author()
		{
		}
	}

}