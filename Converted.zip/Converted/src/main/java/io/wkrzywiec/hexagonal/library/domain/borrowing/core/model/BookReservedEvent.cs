﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{

	public class BookReservedEvent
	{

		private readonly ReservationId reservationId;
		private readonly long? userId;
		private readonly ReservedBook reservedBook;
		private readonly Instant timestamp;

		public BookReservedEvent(ReservationDetails reservationDetails)
		{
			this.reservationId = reservationDetails.ReservationId;
			this.userId = reservationDetails.ReservedBook.AssignedUserIdAsLong;
			this.reservedBook = reservationDetails.ReservedBook;
			timestamp = Instant.now();
		}

		public virtual long? ReservationIdAsLong
		{
			get
			{
				return reservationId.IdAsLong;
			}
		}

		public virtual long? UserIdAsLong
		{
			get
			{
				return userId;
			}
		}

		public virtual long? BookIdAsLong
		{
			get
			{
				return reservedBook.IdAsLong;
			}
		}

		public virtual string EventTimeStampAsString
		{
			get
			{
				return timestamp.ToString();
			}
		}

	}

}