﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception
{
	public class AvailableBookNotFoundExeption : Exception
	{
		public AvailableBookNotFoundExeption(long? bookId) : base("There is no available book with an ID: " + bookId, null, false, false)
		{
		}
	}

}