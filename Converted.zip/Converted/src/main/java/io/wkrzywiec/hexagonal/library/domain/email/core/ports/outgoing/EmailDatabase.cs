﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing
{

	public interface EmailDatabase
	{
		Optional<string> getTitleByBookId(long? bookId);
		Optional<string> getUserEmailAddress(long? userId);
	}

}