﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.application.model
{
	public enum BookStatus
	{
		AVAILABLE,
		RESERVED,
		BORROWED
	}

}