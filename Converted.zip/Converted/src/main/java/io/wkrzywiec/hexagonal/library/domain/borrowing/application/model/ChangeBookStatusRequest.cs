﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.application.model
{
	using Builder = lombok.Builder;
	using Data = lombok.Data;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Data @Builder public class ChangeBookStatusRequest
	public class ChangeBookStatusRequest
	{

		private BookStatus status;
		private long? userId;
	}

}