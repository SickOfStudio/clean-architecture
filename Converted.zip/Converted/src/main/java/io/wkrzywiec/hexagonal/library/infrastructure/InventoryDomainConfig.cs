﻿namespace io.wkrzywiec.hexagonal.library.infrastructure
{
	using InventoryFacade = io.wkrzywiec.hexagonal.library.domain.inventory.core.InventoryFacade;
	using BookRepository = io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.BookRepository;
	using GoogleBooksAdapter = io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.GoogleBooksAdapter;
	using InventoryDatabaseAdapter = io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.InventoryDatabaseAdapter;
	using SpringInventoryEventPublisherAdapter = io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.SpringInventoryEventPublisherAdapter;
	using AddNewBook = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.incoming.AddNewBook;
	using ApplicationEventPublisher = org.springframework.context.ApplicationEventPublisher;
	using Bean = org.springframework.context.annotation.Bean;
	using RestTemplate = org.springframework.web.client.RestTemplate;

	public class InventoryDomainConfig
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean SpringInventoryEventPublisherAdapter springInventoryEventPublisher(org.springframework.context.ApplicationEventPublisher applicationEventPublisher)
		internal virtual SpringInventoryEventPublisherAdapter springInventoryEventPublisher(ApplicationEventPublisher applicationEventPublisher)
		{
			return new SpringInventoryEventPublisherAdapter(applicationEventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean AddNewBook addNewBook(io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure.BookRepository repository, org.springframework.web.client.RestTemplate restTemplate, org.springframework.context.ApplicationEventPublisher applicationEventPublisher)
		internal virtual AddNewBook addNewBook(BookRepository repository, RestTemplate restTemplate, ApplicationEventPublisher applicationEventPublisher)
		{
			return new InventoryFacade(new InventoryDatabaseAdapter(repository), new GoogleBooksAdapter(restTemplate), springInventoryEventPublisher(applicationEventPublisher));
		}
	}

}