﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception
{
	public class ActiveUserNotFoundException : Exception
	{
		public ActiveUserNotFoundException(long? bookId) : base("There is no active user with an ID: " + bookId, null, false, false)
		{
		}
	}

}