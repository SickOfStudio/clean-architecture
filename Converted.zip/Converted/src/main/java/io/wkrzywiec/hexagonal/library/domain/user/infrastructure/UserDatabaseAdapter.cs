﻿namespace io.wkrzywiec.hexagonal.library.domain.user.infrastructure
{
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;
	using UserDatabase = io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class UserDatabaseAdapter implements io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase
	public class UserDatabaseAdapter : UserDatabase
	{

		private readonly UserRepository userRepository;

		public virtual UserIdentifier save(User user)
		{
			User savedUser = userRepository.save(user);
			return new UserIdentifier(savedUser.IdentifierAsLong);
		}
	}

}