﻿namespace io.wkrzywiec.hexagonal.library.domain.user.application
{
	using AddUserCommand = io.wkrzywiec.hexagonal.library.domain.user.core.model.AddUserCommand;
	using AddNewUser = io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming.AddNewUser;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using HttpStatus = org.springframework.http.HttpStatus;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using PostMapping = org.springframework.web.bind.annotation.PostMapping;
	using RequestBody = org.springframework.web.bind.annotation.RequestBody;
	using RequestMapping = org.springframework.web.bind.annotation.RequestMapping;
	using RestController = org.springframework.web.bind.annotation.RestController;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RestController @RequestMapping("/users") @RequiredArgsConstructor public class UserCommandController
	public class UserCommandController
	{

//JAVA TO C# CONVERTER NOTE: Fields cannot have the same name as methods of the current type:
		private readonly AddNewUser addNewUser_Conflict;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @PostMapping("") public org.springframework.http.ResponseEntity<String> addNewUser(@RequestBody AddUserCommand addUserCommand)
		public virtual ResponseEntity<string> addNewUser(AddUserCommand addUserCommand)
		{
			addNewUser_Conflict.handle(addUserCommand);
			return new ResponseEntity<string>("New user was added to library", HttpStatus.CREATED);
		}
	}

}