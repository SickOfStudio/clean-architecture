﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.model
{
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class ReservationConfirmEmail
	public class ReservationConfirmEmail
	{

		private readonly EmailAddress from;
		private readonly EmailAddress to;
		private readonly string subject;
		private readonly string content;

		public virtual string FromEmailAddressAsString
		{
			get
			{
				return this.from.AsString;
			}
		}

		public virtual string ToEmailAddressAsString
		{
			get
			{
				return this.to.AsString;
			}
		}

		public virtual string SubjectAsString
		{
			get
			{
				return this.subject;
			}
		}

		public virtual string ContentAsString
		{
			get
			{
				return this.content;
			}
		}
	}

}