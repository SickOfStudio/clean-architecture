﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;
	using Getter = lombok.Getter;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Getter @EqualsAndHashCode public class ReservationDetails
	public class ReservationDetails
	{

		private readonly ReservationId reservationId;
		private readonly ReservedBook reservedBook;

		public ReservationDetails(ReservationId reservationId, ReservedBook reservedBook)
		{
			this.reservationId = reservationId;
			this.reservedBook = reservedBook;
		}
	}

}