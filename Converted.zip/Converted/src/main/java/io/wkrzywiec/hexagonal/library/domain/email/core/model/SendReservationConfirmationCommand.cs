﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.model
{
	using Getter = lombok.Getter;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Getter public class SendReservationConfirmationCommand
	public class SendReservationConfirmationCommand
	{

		private readonly long? reservationId;
		private readonly long? userId;
		private readonly long? bookId;

		public SendReservationConfirmationCommand(long? reservationId, long? userId, long? bookId)
		{
			this.reservationId = reservationId;
			this.userId = userId;
			this.bookId = bookId;
		}
	}

}