﻿namespace io.wkrzywiec.hexagonal.library.application
{
	using GetMapping = org.springframework.web.bind.annotation.GetMapping;
	using RequestMapping = org.springframework.web.bind.annotation.RequestMapping;
	using RestController = org.springframework.web.bind.annotation.RestController;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RestController @RequestMapping("/") public class LibraryHexagonalController
	public class LibraryHexagonalController
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @GetMapping("") public String getAppRoot()
		public virtual string AppRoot
		{
			get
			{
				return "Library Hexagonal REST API";
			}
		}
	}

}