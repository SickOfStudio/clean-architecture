﻿namespace io.wkrzywiec.hexagonal.library.infrastructure
{
	using EmailFacade = io.wkrzywiec.hexagonal.library.domain.email.core.EmailFacade;
	using EmailDatabaseAdapter = io.wkrzywiec.hexagonal.library.domain.email.infrastructure.EmailDatabaseAdapter;
	using SendGridEmailSender = io.wkrzywiec.hexagonal.library.domain.email.infrastructure.SendGridEmailSender;
	using SendReservationConfirmation = io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming.SendReservationConfirmation;
	using EmailSender = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender;
	using EmailDatabase = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase;
	using Bean = org.springframework.context.annotation.Bean;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;

	public class EmailDomainConfig
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender emailSender()
		public virtual EmailSender emailSender()
		{
			return new SendGridEmailSender();
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase libraryDatabase(org.springframework.jdbc.core.JdbcTemplate jdbcTemplate)
		public virtual EmailDatabase libraryDatabase(JdbcTemplate jdbcTemplate)
		{
			return new EmailDatabaseAdapter(jdbcTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Bean public io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming.SendReservationConfirmation sendReservationConfirmation(io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender emailSender, io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase database)
		public virtual SendReservationConfirmation sendReservationConfirmation(EmailSender emailSender, EmailDatabase database)
		{
			return new EmailFacade(emailSender, database);
		}
	}

}