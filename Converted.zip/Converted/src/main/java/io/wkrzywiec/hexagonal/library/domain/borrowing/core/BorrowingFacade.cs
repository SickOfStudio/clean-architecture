﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core
{
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;
	using BookReservedEvent = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent;
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using GiveBackBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.GiveBackBookCommand;
	using MakeBookAvailableCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.MakeBookAvailableCommand;
	using OverdueReservation = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.OverdueReservation;
	using ReservationDetails = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationDetails;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using ActiveUserNotFoundException = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.ActiveUserNotFoundException;
	using AvailableBookNotFoundExeption = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.AvailableBookNotFoundExeption;
	using BorrowedBookNotFoundException = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.BorrowedBookNotFoundException;
	using ReservedBookNotFoundException = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.ReservedBookNotFoundException;
	using BorrowBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.BorrowBook;
	using CancelOverdueReservations = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.CancelOverdueReservations;
	using GiveBackBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.GiveBackBook;
	using MakeBookAvailable = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.MakeBookAvailable;
	using ReserveBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.ReserveBook;
	using BorrowingDatabase = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase;
	using BorrowingEventPublisher = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher;

	public class BorrowingFacade : MakeBookAvailable, ReserveBook, CancelOverdueReservations, BorrowBook, GiveBackBook
	{

		private readonly BorrowingDatabase database;
		private readonly BorrowingEventPublisher eventPublisher;

		public BorrowingFacade(BorrowingDatabase database, BorrowingEventPublisher eventPublisher)
		{
			this.database = database;
			this.eventPublisher = eventPublisher;
		}

		public virtual void handle(MakeBookAvailableCommand bookAvailableCommand)
		{
			database.save(new AvailableBook(bookAvailableCommand.BookId));
		}

		public virtual long? handle(BookReservationCommand bookReservation)
		{
			AvailableBook availableBook = database.getAvailableBook(bookReservation.BookId).orElseThrow(() => new AvailableBookNotFoundExeption(bookReservation.BookId));

			ActiveUser activeUser = database.getActiveUser(bookReservation.UserId).orElseThrow(() => new ActiveUserNotFoundException(bookReservation.UserId));

			ReservedBook reservedBook = activeUser.reserve(availableBook);
			ReservationDetails reservationDetails = database.save(reservedBook);
			eventPublisher.publish(new BookReservedEvent(reservationDetails));
			return reservationDetails.ReservationId.IdAsLong;
		}

		public virtual void cancelOverdueReservations()
		{
			IList<OverdueReservation> overdueReservationList = database.findReservationsForMoreThan(3L);
			overdueReservationList.ForEach(overdueBook => database.save(new AvailableBook(overdueBook.BookIdentificationAsLong)));
		}

		public virtual void handle(BorrowBookCommand borrowBookCommand)
		{
			ActiveUser activeUser = database.getActiveUser(borrowBookCommand.UserId).orElseThrow(() => new ActiveUserNotFoundException(borrowBookCommand.UserId));
			ReservedBook reservedBook = database.getReservedBook(borrowBookCommand.BookId).orElseThrow(() => new ReservedBookNotFoundException(borrowBookCommand.BookId));

			BorrowedBook borrowedBook = activeUser.borrow(reservedBook);
			database.save(borrowedBook);
		}

		public virtual void handle(GiveBackBookCommand command)
		{
			BorrowedBook borrowedBook = database.getBorrowedBook(command.BookId).orElseThrow(() => new BorrowedBookNotFoundException(command.BookId));
			ActiveUser activeUser = database.getActiveUser(command.UserId).orElseThrow(() => new ActiveUserNotFoundException(command.UserId));

			AvailableBook availableBook = activeUser.giveBack(borrowedBook);
			database.save(availableBook);
		}
	}

}