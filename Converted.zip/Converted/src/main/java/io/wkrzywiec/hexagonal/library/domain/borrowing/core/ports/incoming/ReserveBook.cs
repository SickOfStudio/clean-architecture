﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming
{
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;

	public interface ReserveBook
	{
		long? handle(BookReservationCommand bookReservation);
	}

}