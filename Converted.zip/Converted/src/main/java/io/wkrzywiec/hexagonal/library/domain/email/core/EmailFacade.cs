﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core
{
	using ReservationConfirmEmail = io.wkrzywiec.hexagonal.library.domain.email.core.model.ReservationConfirmEmail;
	using SendReservationConfirmationCommand = io.wkrzywiec.hexagonal.library.domain.email.core.model.SendReservationConfirmationCommand;
	using SendReservationConfirmation = io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming.SendReservationConfirmation;
	using EmailSender = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender;
	using EmailDatabase = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class EmailFacade implements io.wkrzywiec.hexagonal.library.domain.email.core.ports.incoming.SendReservationConfirmation
	public class EmailFacade : SendReservationConfirmation
	{

		private readonly EmailSender emailSender;
		private readonly EmailDatabase database;

		public virtual void handle(SendReservationConfirmationCommand sendReservationConfirmation)
		{
			string bookTitle = database.getTitleByBookId(sendReservationConfirmation.BookId).orElseThrow(() => new System.ArgumentException("Can't get book title from database. Reason: there is no book with an id: " + sendReservationConfirmation.BookId));
			string userEmailAddress = database.getUserEmailAddress(sendReservationConfirmation.UserId).orElseThrow(() => new System.ArgumentException("Can't get email address from database. Reason: there is no user with an id: " + sendReservationConfirmation.UserId));

			ReservationConfirmEmail reservationConfirmEmail = EmailCreator.reservationEmail(sendReservationConfirmation.ReservationId, bookTitle, userEmailAddress);
			emailSender.sendReservationConfirmationEmail(reservationConfirmEmail);
		}
	}

}