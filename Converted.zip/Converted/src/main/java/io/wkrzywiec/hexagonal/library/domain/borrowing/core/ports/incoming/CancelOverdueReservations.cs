﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming
{
	public interface CancelOverdueReservations
	{
		void cancelOverdueReservations();
	}

}