﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.model
{

	public class EmailAddress
	{

		private readonly string value;

		public EmailAddress(string value)
		{
			Pattern pattern = Pattern.compile("^(.+)@(.+)$");
			Matcher matcher = pattern.matcher(value);
			if (matcher.matches())
			{
				this.value = value;
			}
			else
			{
				throw new System.ArgumentException("Provided value is not an email address");
			}

		}

		public virtual string AsString
		{
			get
			{
				return value;
			}
		}
	}

}