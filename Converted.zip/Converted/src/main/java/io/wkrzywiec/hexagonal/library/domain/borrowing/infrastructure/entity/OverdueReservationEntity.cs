﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.entity
{
	using Data = lombok.Data;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Data public class OverdueReservationEntity
	public class OverdueReservationEntity
	{
		private long? reservationId;
		private long? bookIdentification;
	}

}