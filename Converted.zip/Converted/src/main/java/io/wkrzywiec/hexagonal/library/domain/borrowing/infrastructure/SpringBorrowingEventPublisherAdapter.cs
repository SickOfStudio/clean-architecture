﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure
{
	using BookReservedEvent = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent;
	using BorrowingEventPublisher = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using ApplicationEventPublisher = org.springframework.context.ApplicationEventPublisher;
	using Component = org.springframework.stereotype.Component;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Component @RequiredArgsConstructor public class SpringBorrowingEventPublisherAdapter implements io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher
	public class SpringBorrowingEventPublisherAdapter : BorrowingEventPublisher
	{

		private readonly ApplicationEventPublisher eventPublisher;

		public virtual void publish(BookReservedEvent @event)
		{
			eventPublisher.publishEvent(@event);
		}
	}

}