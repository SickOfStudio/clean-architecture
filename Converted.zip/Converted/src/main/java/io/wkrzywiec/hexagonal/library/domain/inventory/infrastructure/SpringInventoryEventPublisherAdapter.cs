﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using NewBookWasAddedEvent = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent;
	using InventoryEventPublisher = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryEventPublisher;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using ApplicationEventPublisher = org.springframework.context.ApplicationEventPublisher;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class SpringInventoryEventPublisherAdapter implements io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryEventPublisher
	public class SpringInventoryEventPublisherAdapter : InventoryEventPublisher
	{

		private readonly ApplicationEventPublisher applicationEventPublisher;

		public virtual void publishNewBookWasAddedEvent(NewBookWasAddedEvent @event)
		{
			applicationEventPublisher.publishEvent(@event);
		}
	}

}