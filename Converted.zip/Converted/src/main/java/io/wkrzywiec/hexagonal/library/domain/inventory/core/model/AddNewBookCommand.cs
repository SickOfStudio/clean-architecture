﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using AllArgsConstructor = lombok.AllArgsConstructor;
	using Builder = lombok.Builder;
	using Getter = lombok.Getter;
	using NoArgsConstructor = lombok.NoArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Getter @AllArgsConstructor @NoArgsConstructor @Builder public class AddNewBookCommand
	public class AddNewBookCommand
	{
		private string googleBookId;
	}

}