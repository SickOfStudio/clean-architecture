﻿using System;
using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using JsonElement = com.google.gson.JsonElement;
	using JsonObject = com.google.gson.JsonObject;
	using JsonParser = com.google.gson.JsonParser;
	using Author = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Author;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using BookIdentification = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.BookIdentification;
	using Isbn10 = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Isbn10;
	using Isbn13 = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Isbn13;
	using GetBookDetails = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.GetBookDetails;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using HttpEntity = org.springframework.http.HttpEntity;
	using HttpHeaders = org.springframework.http.HttpHeaders;
	using HttpMethod = org.springframework.http.HttpMethod;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using RestTemplate = org.springframework.web.client.RestTemplate;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class GoogleBooksAdapter implements io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.GetBookDetails
	public class GoogleBooksAdapter : GetBookDetails
	{

		private readonly RestTemplate restTemplate;

		public virtual Book handle(string googleBookId)
		{

			HttpHeaders requestHeader = new HttpHeaders();
			HttpEntity<object> requestEntity = new HttpEntity<object>(requestHeader);

			ResponseEntity<string> responseEntity = restTemplate.exchange("https://www.googleapis.com/books/v1/volumes/" + googleBookId, HttpMethod.GET, requestEntity, typeof(string));

			JsonObject response = ofNullable(responseEntity.Body).map(stringBody => JsonParser.parseString(stringBody).AsJsonObject).orElseThrow(() => new Exception("There is no body inside the response from Google Books API"));

			JsonObject volumeInfo = response.getAsJsonObject("volumeInfo");

			Isbn10 isbn10 = new Isbn10(extractIsbn(volumeInfo, "ISBN_10"));
			Isbn13 isbn13 = new Isbn13(extractIsbn(volumeInfo, "ISBN_13"));

			return new Book(new BookIdentification(googleBookId, isbn10, isbn13), volumeInfo.get("title").AsString, extractAuthors(volumeInfo), volumeInfo.get("publisher").AsString, volumeInfo.get("publishedDate").AsString, volumeInfo.get("description").AsString, volumeInfo.get("pageCount").AsInt, extractImage(volumeInfo));
		}

		private string extractIsbn(JsonObject volumeInfo, string isbnType)
		{
			return StreamSupport.stream(ofNullable(volumeInfo).map(volume => volume.getAsJsonArray("industryIdentifiers")).orElseThrow(() => new Exception("")).spliterator(), false).map(JsonElement.getAsJsonObject).filter(isbnObject => isbnObject.getAsJsonPrimitive("type").AsString.Equals(isbnType)).map(isbnObject => isbnObject.getAsJsonPrimitive("identifier").AsString).findFirst().orElseThrow(() => new Exception("Inside volumeInfo there is no " + isbnType));
		}

		private ISet<Author> extractAuthors(JsonObject volumeInfo)
		{
//JAVA TO C# CONVERTER TODO TASK: Method reference constructor syntax is not converted by Java to C# Converter:
			return StreamSupport.stream(ofNullable(volumeInfo).map(volume => volume.getAsJsonArray("authors")).orElseThrow(() => new Exception("")).spliterator(), false).map(JsonElement.getAsString).map(Author::new).collect(Collectors.toSet());
		}

		private string extractImage(JsonObject volumeInfo)
		{
			ISet<KeyValuePair<string, JsonElement>> imageLinksSet = volumeInfo.getAsJsonObject("imageLinks").entrySet();

			if (isImageThumbnailLinkInResponse(imageLinksSet))
			{
				return StreamSupport.stream(imageLinksSet.spliterator(), false).filter(imageEntry => imageEntry.Key.Equals("thumbnail")).findFirst().orElseThrow().Value.AsString;
			}
			else
			{
				return StreamSupport.stream(imageLinksSet.spliterator(), false).map(entry => entry.Value.AsString).findAny().orElse("");
			}
		}

		private bool isImageThumbnailLinkInResponse(ISet<KeyValuePair<string, JsonElement>> imageLinksSet)
		{
			return StreamSupport.stream(imageLinksSet.spliterator(), false).filter(entry => entry.Key.Equals("thumbnail")).findFirst().Empty;
		}
	}

}