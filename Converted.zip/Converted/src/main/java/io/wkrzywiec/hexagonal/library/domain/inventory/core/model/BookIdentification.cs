﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embeddable @EqualsAndHashCode public class BookIdentification
	public class BookIdentification
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Column(name="book_external_id") private String bookExternalId;
		private string bookExternalId;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embedded private Isbn10 isbn10;
		private Isbn10 isbn10;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Embedded private Isbn13 isbn13;
		private Isbn13 isbn13;

		public BookIdentification(string bookExternalId, Isbn10 isbn10, Isbn13 isbn13)
		{
			this.bookExternalId = bookExternalId;
			this.isbn10 = isbn10;
			this.isbn13 = isbn13;
		}

		private BookIdentification()
		{
		}
	}

}