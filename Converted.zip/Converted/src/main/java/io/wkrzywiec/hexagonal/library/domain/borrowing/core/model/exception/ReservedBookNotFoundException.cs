﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception
{
	public class ReservedBookNotFoundException : Exception
	{
		public ReservedBookNotFoundException(long? bookId) : base("There is no reserved book with an ID: " + bookId, null, false, false)
		{
		}
	}

}