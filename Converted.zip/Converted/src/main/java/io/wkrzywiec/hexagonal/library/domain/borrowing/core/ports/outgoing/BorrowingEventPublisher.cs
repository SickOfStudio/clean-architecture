﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing
{
	using BookReservedEvent = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent;

	public interface BorrowingEventPublisher
	{
		void publish(BookReservedEvent @event);
	}

}