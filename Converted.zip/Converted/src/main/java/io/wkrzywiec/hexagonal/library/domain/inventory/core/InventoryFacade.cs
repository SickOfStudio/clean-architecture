﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core
{
	using AddNewBookCommand = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.AddNewBookCommand;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using NewBookWasAddedEvent = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent;
	using AddNewBook = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.incoming.AddNewBook;
	using InventoryEventPublisher = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryEventPublisher;
	using GetBookDetails = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.GetBookDetails;
	using InventoryDatabase = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryDatabase;


	public class InventoryFacade : AddNewBook
	{

		private InventoryDatabase database;
		private GetBookDetails getBookDetails;
		private InventoryEventPublisher eventPublisher;

		public InventoryFacade(InventoryDatabase database, GetBookDetails getBookDetails, InventoryEventPublisher eventPublisher)
		{
			this.database = database;
			this.getBookDetails = getBookDetails;
			this.eventPublisher = eventPublisher;
		}

		public virtual void handle(AddNewBookCommand addNewBookCommand)
		{
			Book book = getBookDetails.handle(addNewBookCommand.GoogleBookId);
			Book savedBook = database.save(book);
			eventPublisher.publishNewBookWasAddedEvent(new NewBookWasAddedEvent(savedBook.IdAsLong));
		}
	}

}