﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using InventoryDatabase = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryDatabase;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class InventoryDatabaseAdapter implements io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryDatabase
	public class InventoryDatabaseAdapter : InventoryDatabase
	{

		private readonly BookRepository repository;

		public virtual Book save(Book book)
		{
			return repository.save(book);
		}
	}

}