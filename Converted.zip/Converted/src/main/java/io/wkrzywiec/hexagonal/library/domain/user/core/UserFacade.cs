﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core
{
	using AddUserCommand = io.wkrzywiec.hexagonal.library.domain.user.core.model.AddUserCommand;
	using EmailAddress = io.wkrzywiec.hexagonal.library.domain.user.core.model.EmailAddress;
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;
	using AddNewUser = io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming.AddNewUser;
	using UserDatabase = io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase;
	using AllArgsConstructor = lombok.AllArgsConstructor;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AllArgsConstructor public class UserFacade implements io.wkrzywiec.hexagonal.library.domain.user.core.ports.incoming.AddNewUser
	public class UserFacade : AddNewUser
	{

		private readonly UserDatabase database;

		public virtual UserIdentifier handle(AddUserCommand addUserCommand)
		{
			User user = new User(new EmailAddress(addUserCommand.Email), addUserCommand.FirstName, addUserCommand.LastName);
			return database.save(user);
		}
	}

}