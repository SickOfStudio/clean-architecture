﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure.mapper
{
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using RowMapper = org.springframework.jdbc.core.RowMapper;



	public class BorrowedBookRowMapper : RowMapper<BorrowedBook>
	{

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: @Override public io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook mapRow(java.sql.ResultSet rs, int rowNum) throws java.sql.SQLException
		public override BorrowedBook mapRow(ResultSet rs, int rowNum)
		{
			return new BorrowedBook(rs.getLong("book_id"), rs.getLong("user_id"), rs.getTimestamp("borrowed_date").toInstant());
		}
	}

}