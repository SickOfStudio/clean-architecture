﻿namespace io.wkrzywiec.hexagonal.library.query
{
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using HttpEntity = org.springframework.http.HttpEntity;
	using HttpHeaders = org.springframework.http.HttpHeaders;
	using HttpMethod = org.springframework.http.HttpMethod;
	using MediaType = org.springframework.http.MediaType;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using Component = org.springframework.stereotype.Component;
	using RestTemplate = org.springframework.web.client.RestTemplate;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor @Component public class GoogleBookSearchClient
	public class GoogleBookSearchClient
	{

		private readonly RestTemplate restTemplate;

		public virtual string searchForBooks(string query)
		{

			HttpHeaders requestHeader = new HttpHeaders();
			requestHeader.add("Accept", MediaType.APPLICATION_JSON_VALUE);
			HttpEntity<object> requestEntity = new HttpEntity<object>(requestHeader);

			string searchQuery = "https://www.googleapis.com/books/v1/volumes?langRestrict=en&maxResults=40&printType=books&q=" + query.Trim();

			ResponseEntity<string> responseEntity = restTemplate.exchange(searchQuery, HttpMethod.GET, requestEntity, typeof(string));

			return responseEntity.Body;
		}
	}

}