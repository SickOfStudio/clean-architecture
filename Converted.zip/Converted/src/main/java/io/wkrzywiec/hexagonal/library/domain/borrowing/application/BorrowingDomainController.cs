﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.application
{
	using ChangeBookStatusRequest = io.wkrzywiec.hexagonal.library.domain.borrowing.application.model.ChangeBookStatusRequest;
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;
	using GiveBackBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.GiveBackBookCommand;
	using BorrowBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.BorrowBook;
	using GiveBackBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.GiveBackBook;
	using ReserveBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.ReserveBook;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using Qualifier = org.springframework.beans.factory.annotation.Qualifier;
	using HttpStatus = org.springframework.http.HttpStatus;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using PatchMapping = org.springframework.web.bind.annotation.PatchMapping;
	using PathVariable = org.springframework.web.bind.annotation.PathVariable;
	using RequestBody = org.springframework.web.bind.annotation.RequestBody;
	using RequestMapping = org.springframework.web.bind.annotation.RequestMapping;
	using RestController = org.springframework.web.bind.annotation.RestController;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RestController @RequestMapping("/books") @RequiredArgsConstructor public class BorrowingDomainController
	public class BorrowingDomainController
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Qualifier("GiveBackBook") private final io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.GiveBackBook giveBackBook;
		private readonly GiveBackBook giveBackBook;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Qualifier("ReserveBook") private final io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.ReserveBook reserveBook;
		private readonly ReserveBook reserveBook;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Qualifier("BorrowBook") private final io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming.BorrowBook borrowBook;
//JAVA TO C# CONVERTER NOTE: Fields cannot have the same name as methods of the current type:
		private readonly BorrowBook borrowBook_Conflict;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @PatchMapping("/{id}/status") public org.springframework.http.ResponseEntity<String> borrowBook(@PathVariable("id") System.Nullable<long> bookId, @RequestBody ChangeBookStatusRequest request)
		public virtual ResponseEntity<string> borrowBook(long? bookId, ChangeBookStatusRequest request)
		{
			switch (request.Status)
			{
				case AVAILABLE:
					giveBackBook.handle(new GiveBackBookCommand(bookId, request.UserId));
					return new ResponseEntity<string>("Book with an id " + bookId + " was returned", HttpStatus.OK);
				case RESERVED:
					long? reservationId = reserveBook.handle(new BookReservationCommand(bookId, request.UserId));
					return new ResponseEntity<string>("Reservation has been made with an id " + reservationId, HttpStatus.OK);
				case BORROWED:
					borrowBook_Conflict.handle(new BorrowBookCommand(bookId, request.UserId));
					return new ResponseEntity<string>("Book with an id " + bookId + " was borrowed", HttpStatus.OK);
				default:
					return new ResponseEntity<string>("Book can't have status: " + request.Status, HttpStatus.BAD_REQUEST);
			}
		}
	}

}