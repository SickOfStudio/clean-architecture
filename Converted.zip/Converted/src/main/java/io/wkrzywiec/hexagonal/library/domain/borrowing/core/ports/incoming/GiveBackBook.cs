﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.incoming
{
	using GiveBackBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.GiveBackBookCommand;

	public interface GiveBackBook
	{
		void handle(GiveBackBookCommand command);
	}

}