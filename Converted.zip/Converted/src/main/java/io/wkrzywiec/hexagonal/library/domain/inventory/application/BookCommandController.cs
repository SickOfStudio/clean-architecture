﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.application
{
	using AddNewBookCommand = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.AddNewBookCommand;
	using AddNewBook = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.incoming.AddNewBook;
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using HttpStatus = org.springframework.http.HttpStatus;
	using ResponseEntity = org.springframework.http.ResponseEntity;
	using PostMapping = org.springframework.web.bind.annotation.PostMapping;
	using RequestBody = org.springframework.web.bind.annotation.RequestBody;
	using RequestMapping = org.springframework.web.bind.annotation.RequestMapping;
	using RestController = org.springframework.web.bind.annotation.RestController;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RestController @RequestMapping("/books") @RequiredArgsConstructor public class BookCommandController
	public class BookCommandController
	{

//JAVA TO C# CONVERTER NOTE: Fields cannot have the same name as methods of the current type:
		private readonly AddNewBook addNewBook_Conflict;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @PostMapping("") public org.springframework.http.ResponseEntity<String> addNewBook(@RequestBody AddNewBookCommand addNewBookCommand)
		public virtual ResponseEntity<string> addNewBook(AddNewBookCommand addNewBookCommand)
		{
			addNewBook_Conflict.handle(addNewBookCommand);
			return new ResponseEntity<string>("New book was added to library", HttpStatus.CREATED);
		}
	}

}