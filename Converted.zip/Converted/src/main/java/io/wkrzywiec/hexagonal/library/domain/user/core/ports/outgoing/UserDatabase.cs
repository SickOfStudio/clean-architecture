﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing
{
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;

	public interface UserDatabase
	{
		UserIdentifier save(User user);
	}

}