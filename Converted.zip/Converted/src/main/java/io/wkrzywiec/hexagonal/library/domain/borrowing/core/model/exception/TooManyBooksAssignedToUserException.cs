﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception
{
	public class TooManyBooksAssignedToUserException : Exception
	{
		public TooManyBooksAssignedToUserException(long? userId) : base("You can't assign another book to user account: " + userId + ". Reason: Too many books already assigned.", null, false, false)
		{
		}
	}

}