﻿using System;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception
{
	public class BorrowedBookNotFoundException : Exception
	{
		public BorrowedBookNotFoundException(long? bookId) : base("There is no borrowed book with an ID: " + bookId, null, false, false)
		{
		}
	}

}