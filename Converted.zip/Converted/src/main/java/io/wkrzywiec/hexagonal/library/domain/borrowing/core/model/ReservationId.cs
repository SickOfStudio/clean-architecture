﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	using EqualsAndHashCode = lombok.EqualsAndHashCode;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @EqualsAndHashCode public class ReservationId
	public class ReservationId
	{
		private readonly long? id;

		public ReservationId(long? id)
		{
			this.id = id;
		}

		public virtual long? IdAsLong
		{
			get
			{
				return id;
			}
		}
	}

}