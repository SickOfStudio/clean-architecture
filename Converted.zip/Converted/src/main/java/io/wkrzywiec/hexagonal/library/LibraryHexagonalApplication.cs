﻿namespace io.wkrzywiec.hexagonal.library
{
	using BorrowingDomainConfig = io.wkrzywiec.hexagonal.library.infrastructure.BorrowingDomainConfig;
	using EmailDomainConfig = io.wkrzywiec.hexagonal.library.infrastructure.EmailDomainConfig;
	using InventoryDomainConfig = io.wkrzywiec.hexagonal.library.infrastructure.InventoryDomainConfig;
	using LibraryHexagonalConfig = io.wkrzywiec.hexagonal.library.infrastructure.LibraryHexagonalConfig;
	using UserDomainConfig = io.wkrzywiec.hexagonal.library.infrastructure.UserDomainConfig;
	using SpringApplication = org.springframework.boot.SpringApplication;
	using SpringBootApplication = org.springframework.boot.autoconfigure.SpringBootApplication;
	using Import = org.springframework.context.annotation.Import;
	using EnableScheduling = org.springframework.scheduling.annotation.EnableScheduling;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootApplication @EnableScheduling @Import({ LibraryHexagonalConfig.class, InventoryDomainConfig.class, BorrowingDomainConfig.class, EmailDomainConfig.class, UserDomainConfig.class }) public class LibraryHexagonalApplication
	public class LibraryHexagonalApplication
	{

		public static void Main(string[] args)
		{
			SpringApplication.run(typeof(LibraryHexagonalApplication), args);
		}
	}

}