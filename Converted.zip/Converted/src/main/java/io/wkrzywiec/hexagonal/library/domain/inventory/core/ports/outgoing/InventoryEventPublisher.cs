﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing
{
	using NewBookWasAddedEvent = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent;

	public interface InventoryEventPublisher
	{
		void publishNewBookWasAddedEvent(NewBookWasAddedEvent @event);
	}

}