﻿namespace io.wkrzywiec.hexagonal.library.domain.user.core.model
{

	public class UserIdentifier
	{

		private readonly long? id;

		public UserIdentifier(long? id)
		{
			this.id = id;
		}

		public virtual long? AsLong
		{
			get
			{
				return id;
			}
		}
	}

}