﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.core.model
{
	internal interface Book
	{
		long? IdAsLong {get;}
	}

}