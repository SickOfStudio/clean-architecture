﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core
{
	using EmailAddress = io.wkrzywiec.hexagonal.library.domain.email.core.model.EmailAddress;
	using ReservationConfirmEmail = io.wkrzywiec.hexagonal.library.domain.email.core.model.ReservationConfirmEmail;

	internal class EmailCreator
	{

		internal static ReservationConfirmEmail reservationEmail(long? reservationId, string bookTitle, string emailTo)
		{

			EmailAddress from = new EmailAddress("tom@library.com");
			EmailAddress to = new EmailAddress(emailTo);

			string subject = string.Format("Library - book reservation confirmation (id - {0:D})", reservationId);
//JAVA TO C# CONVERTER TODO TASK: The following line has a Java format specifier which cannot be directly translated to .NET:
			string content = string.Format("Dear reader,%n you have reserved a %s book which will be waiting for you in our library for next 2 days. Your reservation id is %d. %n Have a nice day, %n Library", bookTitle, reservationId);
			return new ReservationConfirmEmail(from, to, subject, content);
		}
	}

}