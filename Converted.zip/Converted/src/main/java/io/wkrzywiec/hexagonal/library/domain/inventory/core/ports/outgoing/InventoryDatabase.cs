﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing
{
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;

	public interface InventoryDatabase
	{
		Book save(Book book);
	}

}