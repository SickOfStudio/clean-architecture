﻿namespace io.wkrzywiec.hexagonal.library.domain.email
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using UserTestData = io.wkrzywiec.hexagonal.library.UserTestData;
	using EmailFacade = io.wkrzywiec.hexagonal.library.domain.email.core.EmailFacade;
	using SendReservationConfirmationCommand = io.wkrzywiec.hexagonal.library.domain.email.core.model.SendReservationConfirmationCommand;
	using EmailSender = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

	public class EmailFacadeTest
	{

		private EmailFacade facade;
		private EmailSender emailSender;
		private InMemoryEmailDatabase database;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new InMemoryEmailDatabase();
			emailSender = new EmailSenderFake();
			facade = new EmailFacade(emailSender, database);

			database.bookTitles[1L] = BookTestData.homoDeusBookTitle();
			database.emailAddresses[1L] = UserTestData.johnDoeEmail();
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Prepare & send reservation confirmation email") public void shouldPrepareAndSendReservationConfirmation()
		public virtual void shouldPrepareAndSendReservationConfirmation()
		{
			//given
			SendReservationConfirmationCommand sendReservationConfirmationCommand = new SendReservationConfirmationCommand(1L, 1L, 1L);

			//when & then
			assertDoesNotThrow(() => facade.handle(sendReservationConfirmationCommand));
		}
	}

}