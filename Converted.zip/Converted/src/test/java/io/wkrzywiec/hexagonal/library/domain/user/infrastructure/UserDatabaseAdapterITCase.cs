﻿namespace io.wkrzywiec.hexagonal.library.domain.user.infrastructure
{
	using DatabaseHelper = io.wkrzywiec.hexagonal.library.DatabaseHelper;
	using UserTestData = io.wkrzywiec.hexagonal.library.UserTestData;
	using EmailAddress = io.wkrzywiec.hexagonal.library.domain.user.core.model.EmailAddress;
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using SpringBootTest = org.springframework.boot.test.context.SpringBootTest;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootTest public class UserDatabaseAdapterITCase
	public class UserDatabaseAdapterITCase
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
		private JdbcTemplate jdbcTemplate;
		private DatabaseHelper databaseHelper;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private UserRepository userRepository;
		private UserRepository userRepository;

		private UserDatabaseAdapter userDatabase;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			userDatabase = new UserDatabaseAdapter(userRepository);
			databaseHelper = new DatabaseHelper(jdbcTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Save new user in database") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldSaveDatabase()
		public virtual void shouldSaveDatabase()
		{
			//given
			User user = new User(new EmailAddress(UserTestData.johnDoeEmail()), "John", "Doe");

			//when
			UserIdentifier userIdentifier = userDatabase.save(user);

			//then
			long? savedUserId = databaseHelper.JohnDoeUserId;

			assertEquals(userIdentifier.AsLong, savedUserId);
		}
	}

}