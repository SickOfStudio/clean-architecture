﻿namespace io.wkrzywiec.hexagonal.library
{
	using RequiredArgsConstructor = lombok.RequiredArgsConstructor;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @RequiredArgsConstructor public class DatabaseHelper
	public class DatabaseHelper
	{

		private readonly JdbcTemplate jdbcTemplate;

		public virtual long? HomoDeusBookId
		{
			get
			{
				return jdbcTemplate.queryForObject("SELECT id FROM book WHERE title = ?", typeof(Long), BookTestData.homoDeusBookTitle());
			}
		}

		public virtual long? JohnDoeUserId
		{
			get
			{
				return jdbcTemplate.queryForObject("SELECT id FROM library_user WHERE email = ?", typeof(Long), UserTestData.johnDoeEmail());
			}
		}

		public virtual long? getPrimaryKeyOfAvailableByBookBy(long? bookId)
		{
			return jdbcTemplate.queryForObject("SELECT book_id FROM available WHERE book_id = ?", typeof(Long), bookId);
		}

		public virtual long? getPrimaryKeyOfReservationByBookId(long? bookId)
		{
			return jdbcTemplate.queryForObject("SELECT id FROM reserved WHERE book_id = ?", typeof(Long), bookId);
		}

		public virtual long? getPrimaryKeyOfBorrowedByBookId(long? bookId)
		{
			return jdbcTemplate.queryForObject("SELECT book_id FROM borrowed WHERE book_id = ?", typeof(Long), bookId);
		}
	}

}