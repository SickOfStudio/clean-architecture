﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using GiveBackBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.GiveBackBookCommand;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;


	public class BorrowTestData
	{

		public static BorrowBookCommand anyBorrowBookCommand(long? bookId, long? userId)
		{
			return BorrowBookCommand.builder().bookId(bookId).userId(userId).build();
		}

		public static GiveBackBookCommand anyGiveBookCommand(long? bookId, long? userId)
		{
			return GiveBackBookCommand.builder().bookId(bookId).userId(userId).build();
		}

		public static ReservedBook anyReservedBook(long? bookId, long? userId)
		{
			return new ReservedBook(bookId, userId);
		}

		public static BorrowedBook anyBorrowedBook(long? bookId, long? userId)
		{
			return new BorrowedBook(bookId, userId);
		}

		public static ActiveUser anyActiveUser(long? userId)
		{
			return new ActiveUser(userId, new List<ReservedBook>(), new List<BorrowedBook>());
		}

		public static ActiveUser anyActiveUserWithReservedBooks(long? userId, IList<ReservedBook> reservedBookList)
		{
			return new ActiveUser(userId, reservedBookList, new List<BorrowedBook>());
		}

		public static ActiveUser anyActiveUserWithBorrowedBooks(long? userId, IList<BorrowedBook> borrowedBooksList)
		{
			return new ActiveUser(userId, new List<ReservedBook>(), borrowedBooksList);
		}

	}

}