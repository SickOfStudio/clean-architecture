﻿namespace io.wkrzywiec.hexagonal.library.domain.email.infrastructure
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using DatabaseHelper = io.wkrzywiec.hexagonal.library.DatabaseHelper;
	using UserTestData = io.wkrzywiec.hexagonal.library.UserTestData;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using SpringBootTest = org.springframework.boot.test.context.SpringBootTest;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootTest public class EmailDatabaseAdapterITCase
	public class EmailDatabaseAdapterITCase
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
		private JdbcTemplate jdbcTemplate;
		private DatabaseHelper databaseHelper;
		private EmailDatabaseAdapter emailDatabase;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			emailDatabase = new EmailDatabaseAdapter(jdbcTemplate);
			databaseHelper = new DatabaseHelper(jdbcTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get book title from db by its id") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenBookId_whenGetBookTitle_thenGetBookTitle()
		public virtual void givenBookId_whenGetBookTitle_thenGetBookTitle()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			Optional<string> bookTitle = emailDatabase.getTitleByBookId(bookId);

			//then
			assertEquals(BookTestData.homoDeusBookTitle(), bookTitle);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get empty result when book is not in db") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenWrongBookId_whenGetBookTitle_thenGetEmptyResult()
		public virtual void givenWrongBookId_whenGetBookTitle_thenGetEmptyResult()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			Optional<string> bookTitle = emailDatabase.getTitleByBookId(bookId.Value + 1124);

			//then
			assertEquals(null, bookTitle);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get email from db by user id") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenUserId_whenGetEmail_thenGetEmailAddress()
		public virtual void givenUserId_whenGetEmail_thenGetEmailAddress()
		{
			//given
			long? userId = databaseHelper.JohnDoeUserId;

			//when
			Optional<string> emailAddress = emailDatabase.getUserEmailAddress(userId);

			//then
			assertEquals(UserTestData.johnDoeEmail(), emailAddress);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get empty result when book is not in db") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenWrongUserId_whenGetEmail_thenGetEmptyResult()
		public virtual void givenWrongUserId_whenGetEmail_thenGetEmptyResult()
		{
			//given
			long? userId = databaseHelper.JohnDoeUserId;

			//when
			Optional<string> emailAddress = emailDatabase.getUserEmailAddress(userId.Value + 1124);

			//then
			assertEquals(null, emailAddress);
		}
	}

}