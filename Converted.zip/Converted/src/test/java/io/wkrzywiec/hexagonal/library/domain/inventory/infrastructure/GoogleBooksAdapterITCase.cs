﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using MediaType = org.springframework.http.MediaType;
	using MockRestServiceServer = org.springframework.test.web.client.MockRestServiceServer;
	using RestTemplate = org.springframework.web.client.RestTemplate;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

	public class GoogleBooksAdapterITCase
	{

		private GoogleBooksAdapter googleBooks;
		private RestTemplate restTemplate;
		private MockRestServiceServer server;


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			restTemplate = new RestTemplate();
			server = MockRestServiceServer.createServer(restTemplate);
			googleBooks = new GoogleBooksAdapter(restTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get book details from Google Books") public void givenCorrectBookId_whenGetBookDetails_thenReturnBookDetailsDTO()
		public virtual void givenCorrectBookId_whenGetBookDetails_thenReturnBookDetailsDTO()
		{
			//given
			string homoDeusResponse = BookTestData.homoDeusGooleBooksResponse();
			Book homoDeusBook = BookTestData.homoDeusBook();
			server.expect(requestTo("https://www.googleapis.com/books/v1/volumes/" + BookTestData.homoDeusBookGoogleId())).andRespond(withSuccess(homoDeusResponse, MediaType.APPLICATION_JSON));

			//when
			Book actualBook = googleBooks.handle(BookTestData.homoDeusBookGoogleId());

			//then
			assertEquals(homoDeusBook, actualBook);
		}
	}

}