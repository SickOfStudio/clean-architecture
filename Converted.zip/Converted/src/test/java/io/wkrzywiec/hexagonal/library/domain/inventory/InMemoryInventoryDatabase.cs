﻿using System;
using System.Collections.Concurrent;

namespace io.wkrzywiec.hexagonal.library.domain.inventory
{
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using InventoryDatabase = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryDatabase;
	using FieldUtils = org.apache.commons.lang3.reflect.FieldUtils;


	public class InMemoryInventoryDatabase : InventoryDatabase
	{

		internal ConcurrentDictionary<long, Book> books = new ConcurrentDictionary<long, Book>();

		public virtual Book save(Book book)
		{
			long? id = books.Count + 1L;

			try
			{
				FieldUtils.writeField(book, "id", id, true);
			}
			catch (IllegalAccessException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
			}
			books[id] = book;
			return book;
		}
	}

}