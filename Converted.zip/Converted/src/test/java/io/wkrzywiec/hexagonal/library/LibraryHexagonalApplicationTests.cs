﻿namespace io.wkrzywiec.hexagonal.library
{
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using ExtendWith = org.junit.jupiter.api.extension.ExtendWith;
	using SpringExtension = org.springframework.test.context.junit.jupiter.SpringExtension;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ExtendWith(SpringExtension.class) class LibraryHexagonalApplicationTests
	internal class LibraryHexagonalApplicationTests
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Test if Spring context is built") void contextLoads()
		internal virtual void contextLoads()
		{
		}

	}

}