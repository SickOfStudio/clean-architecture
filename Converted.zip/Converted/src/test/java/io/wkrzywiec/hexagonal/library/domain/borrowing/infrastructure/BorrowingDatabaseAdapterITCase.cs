﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure
{
	using DatabaseHelper = io.wkrzywiec.hexagonal.library.DatabaseHelper;
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using DueDate = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.DueDate;
	using OverdueReservation = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.OverdueReservation;
	using ReservationDetails = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationDetails;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using SpringBootTest = org.springframework.boot.test.context.SpringBootTest;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;
	using Sql = org.springframework.test.context.jdbc.Sql;


//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootTest public class BorrowingDatabaseAdapterITCase
	public class BorrowingDatabaseAdapterITCase
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
		private JdbcTemplate jdbcTemplate;
		private DatabaseHelper databaseHelper;
		private BorrowingDatabaseAdapter database;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new BorrowingDatabaseAdapter(jdbcTemplate);
			databaseHelper = new DatabaseHelper(jdbcTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Save book as available") @Sql("/book-and-user.sql") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldSaveAvailableBook()
		public virtual void shouldSaveAvailableBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			database.save(new AvailableBook(bookId));

			//then
			long? id = databaseHelper.getPrimaryKeyOfAvailableByBookBy(bookId);
			assertTrue(id > 0);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get available book by id") @Sql({"/book-and-user.sql", "/available-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldGetAvailableBook()
		public virtual void shouldGetAvailableBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			Optional<AvailableBook> availableBookOptional = database.getAvailableBook(bookId);

			//then
			assertTrue(availableBookOptional.Present);
			assertEquals(bookId, availableBookOptional.get().IdAsLong);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get active user by id") @Sql("/book-and-user.sql") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldGetActiveUser()
		public virtual void shouldGetActiveUser()
		{
			//given
			long? activeUserId = databaseHelper.JohnDoeUserId;

			//when
			Optional<ActiveUser> activeUserOptional = database.getActiveUser(activeUserId);

			//then
			assertTrue(activeUserOptional.Present);
			assertEquals(activeUserId, activeUserOptional.get().IdAsLong);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Save reserved book") @Sql({"/book-and-user.sql", "/available-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldSaveReservedBook()
		public virtual void shouldSaveReservedBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;
			long? activeUserId = databaseHelper.JohnDoeUserId;

			ReservedBook reservedBook = new ReservedBook(bookId, activeUserId);

			//when
			ReservationDetails reservationDetails = database.save(reservedBook);

			//then
			assertEquals(bookId, reservationDetails.ReservedBook.IdAsLong);
			assertEquals(activeUserId, reservationDetails.ReservedBook.AssignedUserIdAsLong);
			assertTrue(reservationDetails.ReservationId.IdAsLong > 0);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Get reserved book by its id") @Sql({"/book-and-user.sql", "/reserved-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldFindReservedBook()
		public virtual void shouldFindReservedBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			Optional<ReservedBook> reservedBook = database.getReservedBook(bookId);

			//then
			assertTrue(reservedBook.Present);
			assertEquals(bookId, reservedBook.get().IdAsLong);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Save borrowed book") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldSaveBorrowedBook()
		public virtual void shouldSaveBorrowedBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;
			long? activeUserId = databaseHelper.JohnDoeUserId;

			BorrowedBook borrowedBook = new BorrowedBook(bookId, activeUserId);

			//when
			database.save(borrowedBook);

			//then
			long? savedBookId = databaseHelper.getPrimaryKeyOfBorrowedByBookId(bookId);
			assertEquals(bookId, savedBookId);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Find book after 3 days of reservation") @Sql({"/book-and-user.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldFindOverdueReservations()
		public virtual void shouldFindOverdueReservations()
		{
			//given
			long? overdueBookId = databaseHelper.HomoDeusBookId;
			long? johnDoeUserId = databaseHelper.JohnDoeUserId;
			jdbcTemplate.update("INSERT INTO public.reserved (book_id, user_id, reserved_date) VALUES (?, ?, ?)", overdueBookId, johnDoeUserId, Instant.now().plus(4, ChronoUnit.DAYS));

			//when
			OverdueReservation overdueReservation = database.findReservationsForMoreThan(3L)[0];

			//then
			assertEquals(overdueBookId, overdueReservation.BookIdentificationAsLong);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Find borrowed book by id") @Sql({"/book-and-user.sql", "/borrowed-book.sql"}) @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void shouldFindBorrowedBook()
		public virtual void shouldFindBorrowedBook()
		{
			//given
			long? bookId = databaseHelper.HomoDeusBookId;

			//when
			Optional<BorrowedBook> borrowedBook = database.getBorrowedBook(bookId);

			//then
			assertTrue(borrowedBook.Present);
			assertEquals(bookId, borrowedBook.get().IdAsLong);
		}
	}

}