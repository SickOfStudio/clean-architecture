﻿using System;
using System.Collections.Concurrent;

namespace io.wkrzywiec.hexagonal.library.domain.user
{
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;
	using UserDatabase = io.wkrzywiec.hexagonal.library.domain.user.core.ports.outgoing.UserDatabase;
	using FieldUtils = org.apache.commons.lang3.reflect.FieldUtils;

	public class InMemoryUserDatabase : UserDatabase
	{

		internal ConcurrentDictionary<long, User> users = new ConcurrentDictionary<long, User>();

		public virtual UserIdentifier save(User user)
		{
			long? id = users.Count + 1L;

			try
			{
				FieldUtils.writeField(user, "id", id, true);
			}
			catch (IllegalAccessException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
			}
			users[id] = user;
			return new UserIdentifier(id);
		}
	}

}