﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.inventory
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using GetBookDetails = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.GetBookDetails;


	public class GetBookDetailsFake : GetBookDetails
	{

		private IDictionary<string, Book> books;

		public GetBookDetailsFake()
		{
			books = new Dictionary<string, Book>();
			books[BookTestData.homoDeusBookGoogleId()] = BookTestData.homoDeusBook();
		}

		public virtual Book handle(string bookId)
		{
			return books[bookId];
		}
	}

}