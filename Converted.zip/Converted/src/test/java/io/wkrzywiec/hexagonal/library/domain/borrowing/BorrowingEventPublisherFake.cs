﻿namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using BookReservedEvent = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservedEvent;
	using BorrowingEventPublisher = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher;

	public class BorrowingEventPublisherFake : BorrowingEventPublisher
	{

		public virtual void publish(BookReservedEvent @event)
		{

		}
	}

}