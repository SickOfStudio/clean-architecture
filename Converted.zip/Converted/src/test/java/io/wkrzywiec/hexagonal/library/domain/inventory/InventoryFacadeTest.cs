﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using InventoryFacade = io.wkrzywiec.hexagonal.library.domain.inventory.core.InventoryFacade;
	using AddNewBookCommand = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.AddNewBookCommand;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using GetBookDetails = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.GetBookDetails;
	using InventoryEventPublisher = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryEventPublisher;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertNotNull;


	public class InventoryFacadeTest
	{

		private GetBookDetails getBookDetails;
		private InMemoryInventoryDatabase database;
		private InventoryEventPublisher eventPublisher;
		private InventoryFacade facade;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new InMemoryInventoryDatabase();
			getBookDetails = new GetBookDetailsFake();
			eventPublisher = new InvenotryEventPublisherFake();
			facade = new InventoryFacade(database, getBookDetails, eventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Correctly save a new book in a repository") public void correctlySaveBook()
		public virtual void correctlySaveBook()
		{
			//given
			AddNewBookCommand externalBookId = AddNewBookCommand.builder().googleBookId(BookTestData.homoDeusBookGoogleId()).build();

			//when
			facade.handle(externalBookId);

			//then
			Book actualBook = database.books[1L];
			assertNotNull(actualBook);
		}
	}

}