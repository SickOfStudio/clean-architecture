﻿namespace io.wkrzywiec.hexagonal.library.architecture
{
	using ImportOption = com.tngtech.archunit.core.importer.ImportOption;
	using AnalyzeClasses = com.tngtech.archunit.junit.AnalyzeClasses;
	using ArchTest = com.tngtech.archunit.junit.ArchTest;
	using ArchRule = com.tngtech.archunit.lang.ArchRule;
	using InventoryFacade = io.wkrzywiec.hexagonal.library.domain.inventory.core.InventoryFacade;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClass;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.library.Architectures.onionArchitecture;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AnalyzeClasses(packages = {"io.wkrzywiec.hexagonal.library.domain.inventory"}, importOptions = { ImportOption.DoNotIncludeTests.class }) public class InventoryArchitectureTest
	public class InventoryArchitectureTest
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule hexagonalArchInInventoryDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.inventory.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.inventory..").applicationServices("io.wkrzywiec.hexagonal.library.domain.inventory.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure..");
		public static readonly ArchRule hexagonalArchInInventoryDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.inventory.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.inventory..").applicationServices("io.wkrzywiec.hexagonal.library.domain.inventory.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure..");

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule noSpringDependenciesInInventoryFacade = noClass(io.wkrzywiec.hexagonal.library.domain.inventory.core.InventoryFacade.class).should().dependOnClassesThat().resideInAPackage("org.springframework..");
		public static readonly ArchRule noSpringDependenciesInInventoryFacade = noClass(typeof(InventoryFacade)).should().dependOnClassesThat().resideInAPackage("org.springframework..");

	}

}