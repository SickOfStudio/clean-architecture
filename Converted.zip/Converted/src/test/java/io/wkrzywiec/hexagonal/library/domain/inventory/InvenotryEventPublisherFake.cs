﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory
{
	using NewBookWasAddedEvent = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.NewBookWasAddedEvent;
	using InventoryEventPublisher = io.wkrzywiec.hexagonal.library.domain.inventory.core.ports.outgoing.InventoryEventPublisher;

	public class InvenotryEventPublisherFake : InventoryEventPublisher
	{

		public virtual void publishNewBookWasAddedEvent(NewBookWasAddedEvent @event)
		{
		}
	}

}