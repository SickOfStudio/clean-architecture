﻿namespace io.wkrzywiec.hexagonal.library.domain.email
{
	using ReservationConfirmEmail = io.wkrzywiec.hexagonal.library.domain.email.core.model.ReservationConfirmEmail;
	using EmailSender = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailSender;

	public class EmailSenderFake : EmailSender
	{

		public virtual void sendReservationConfirmationEmail(ReservationConfirmEmail reservationConfirmEmail)
		{

		}
	}

}