﻿namespace io.wkrzywiec.hexagonal.library.architecture
{
	using ImportOption = com.tngtech.archunit.core.importer.ImportOption;
	using AnalyzeClasses = com.tngtech.archunit.junit.AnalyzeClasses;
	using ArchTest = com.tngtech.archunit.junit.ArchTest;
	using ArchRule = com.tngtech.archunit.lang.ArchRule;
	using EmailFacade = io.wkrzywiec.hexagonal.library.domain.email.core.EmailFacade;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClass;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.library.Architectures.onionArchitecture;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AnalyzeClasses(packages = {"io.wkrzywiec.hexagonal.library.domain.email"}, importOptions = { ImportOption.DoNotIncludeTests.class }) public class EmailArchitectureTest
	public class EmailArchitectureTest
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule hexagonalArchInEmailDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.email.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.email..").applicationServices("io.wkrzywiec.hexagonal.library.domain.email.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.email.infrastructure..");
		public static readonly ArchRule hexagonalArchInEmailDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.email.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.email..").applicationServices("io.wkrzywiec.hexagonal.library.domain.email.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.email.infrastructure..");

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule noSpringDependenciesInEmailFacade = noClass(io.wkrzywiec.hexagonal.library.domain.email.core.EmailFacade.class).should().dependOnClassesThat().resideInAPackage("org.springframework..");
		public static readonly ArchRule noSpringDependenciesInEmailFacade = noClass(typeof(EmailFacade)).should().dependOnClassesThat().resideInAPackage("org.springframework..");
	}

}