﻿using System.Collections.Concurrent;

namespace io.wkrzywiec.hexagonal.library.domain.email
{
	using EmailDatabase = io.wkrzywiec.hexagonal.library.domain.email.core.ports.outgoing.EmailDatabase;


	public class InMemoryEmailDatabase : EmailDatabase
	{

		internal ConcurrentDictionary<long, string> bookTitles = new ConcurrentDictionary<long, string>();
		internal ConcurrentDictionary<long, string> emailAddresses = new ConcurrentDictionary<long, string>();

		public virtual Optional<string> getTitleByBookId(long? bookId)
		{
			return bookTitles[bookId];
		}

		public virtual Optional<string> getUserEmailAddress(long? userId)
		{
			return emailAddresses[userId];
		}
	}

}