﻿namespace io.wkrzywiec.hexagonal.library.domain.email.core.model
{
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertThrows;

	public class EmailAddressTest
	{


//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Create correct EmailAddress") public void givenCorrectEmailString_whenCreateEmailAddress_thenIsCreated()
		public virtual void givenCorrectEmailString_whenCreateEmailAddress_thenIsCreated()
		{
			//given
			string emailString = "john.doe@test.com";

			//when
			EmailAddress emailAddress = new EmailAddress(emailString);

			//then
			assertEquals(emailString, emailAddress.AsString);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Throw IllegalArgument exception for incorrect email") public void givenInCorrectEmailString_whenCreateEmailAddress_thenThrowException()
		public virtual void givenInCorrectEmailString_whenCreateEmailAddress_thenThrowException()
		{
			//given
			string notAnEmailString = "not an email";
			string emailWithoutAt = "tom[at]test.com";
			string emailWithoutDomain = "tom@";

			//when & then
			assertThrows(typeof(System.ArgumentException), () => new EmailAddress(notAnEmailString));

			assertThrows(typeof(System.ArgumentException), () => new EmailAddress(emailWithoutAt));

			assertThrows(typeof(System.ArgumentException), () => new EmailAddress(emailWithoutDomain));
		}
	}

}