﻿namespace io.wkrzywiec.hexagonal.library
{
	public class UserTestData
	{

		public static string johnDoeEmail()
		{
			return "john.doe@test.com";
		}
	}

}