﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.core.model
{
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertThrows;

	public class IsbnTest
	{

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("ISBN-10 is created correctly") public void shouldCreateCorrectISBN10()
		public virtual void shouldCreateCorrectISBN10()
		{
			assertEquals("1473545374", (new Isbn10("1473545374")).AsString);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("ISBN-10 is not created") public void shouldNotCreateCorrectISBN10()
		public virtual void shouldNotCreateCorrectISBN10()
		{
			assertThrows(typeof(System.ArgumentException), () => (new Isbn10("9781473545373")).AsString);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("ISBN-13 is created correctly") public void shouldCreateCorrectISBN13()
		public virtual void shouldCreateCorrectISBN13()
		{
			assertEquals("9781473545373", (new Isbn13("9781473545373")).AsString);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("ISBN-13 is not created") public void shouldNotCreateCorrectISBN13()
		public virtual void shouldNotCreateCorrectISBN13()
		{
			assertThrows(typeof(System.ArgumentException), () => (new Isbn13("1473545374")).AsString);
		}
	}

}