﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per file.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

using System;
using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using BorrowingFacade = io.wkrzywiec.hexagonal.library.domain.borrowing.core.BorrowingFacade;
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;
	using BorrowBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowBookCommand;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using GiveBackBookCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.GiveBackBookCommand;
	using MakeBookAvailableCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.MakeBookAvailableCommand;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using ActiveUserNotFoundException = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.ActiveUserNotFoundException;
	using AvailableBookNotFoundExeption = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.AvailableBookNotFoundExeption;
	using TooManyBooksAssignedToUserException = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.exception.TooManyBooksAssignedToUserException;
	using BorrowingEventPublisher = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingEventPublisher;
	using FieldUtils = org.apache.commons.lang3.reflect.FieldUtils;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;


//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertThrows;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;

	public class BorrowingFacadeTest
	{

		private BorrowingFacade facade;
		private InMemoryBorrowingDatabase database;
		private BorrowingEventPublisher eventPublisher;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new InMemoryBorrowingDatabase();
			eventPublisher = new BorrowingEventPublisherFake();
			facade = new BorrowingFacade(database, eventPublisher);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Make book available") public void whenMakeBookAvailableCommandReceived_thenBookIsOnAvailableStatus()
		public virtual void whenMakeBookAvailableCommandReceived_thenBookIsOnAvailableStatus()
		{
			//given
			MakeBookAvailableCommand makeBookAvailableCommand = MakeBookAvailableCommand.builder().bookId(100L).build();

			//when
			facade.handle(makeBookAvailableCommand);

			//then
			assertTrue(database.availableBooks.ContainsKey(100L));
//JAVA TO C# CONVERTER TODO TASK: There is no .NET Dictionary equivalent to the Java ConcurrentHashMap 'containsValue' method:
			assertTrue(database.availableBooks.containsValue(new AvailableBook(100L)));
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Make successful book reservation") public void givenAvailableBooksAndActiveUser_whenMakingReservation_thenBookIsReserved()
		public virtual void givenAvailableBooksAndActiveUser_whenMakingReservation_thenBookIsReserved()
		{
			//given
			BookReservationCommand reservationCommand = ReservationTestData.anyBookReservationCommand(100L, 100L);
			AvailableBook availableBook = ReservationTestData.anyAvailableBook(reservationCommand.BookId);
			ActiveUser activeUser = ReservationTestData.anyActiveUser(reservationCommand.UserId);

			database.activeUsers[activeUser.IdAsLong] = activeUser;
			database.availableBooks[availableBook.IdAsLong] = availableBook;

			//when
			facade.handle(reservationCommand);

			//then
			assertEquals(1, activeUser.ReservedBookList.Count);
			assertEquals(availableBook.IdAsLong, activeUser.ReservedBookList[0].IdAsLong);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("User can't have more than 3 reservations") public void givenActiveUserAlreadyHas3Books_whenMakingReservation_thenBookIsNotReserved()
		public virtual void givenActiveUserAlreadyHas3Books_whenMakingReservation_thenBookIsNotReserved()
		{
			//given
			BookReservationCommand firstReservationCommand = ReservationTestData.anyBookReservationCommand(100L, 100L);
			BookReservationCommand secondReservationCommand = ReservationTestData.anyBookReservationCommand(101L, 100L);
			BookReservationCommand thirdReservationCommand = ReservationTestData.anyBookReservationCommand(102L, 100L);
			BookReservationCommand fourthReservationCommand = ReservationTestData.anyBookReservationCommand(103L, 100L);

			AvailableBook availableBookNo1 = ReservationTestData.anyAvailableBook(firstReservationCommand.BookId);
			AvailableBook availableBookNo2 = ReservationTestData.anyAvailableBook(secondReservationCommand.BookId);
			AvailableBook availableBookNo3 = ReservationTestData.anyAvailableBook(thirdReservationCommand.BookId);
			AvailableBook availableBookNo4 = ReservationTestData.anyAvailableBook(fourthReservationCommand.BookId);

			ActiveUser activeUser = ReservationTestData.anyActiveUser(firstReservationCommand.UserId);

			database.availableBooks[availableBookNo1.IdAsLong] = availableBookNo1;
			database.availableBooks[availableBookNo2.IdAsLong] = availableBookNo2;
			database.availableBooks[availableBookNo3.IdAsLong] = availableBookNo3;
			database.availableBooks[availableBookNo4.IdAsLong] = availableBookNo4;
			database.activeUsers[activeUser.IdAsLong] = activeUser;

			facade.handle(firstReservationCommand);
			facade.handle(secondReservationCommand);
			facade.handle(thirdReservationCommand);

			//when & then
			assertThrows(typeof(TooManyBooksAssignedToUserException), () => facade.handle(fourthReservationCommand));
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Try to reserve book,but it's not available") public void givenNotAvailableBook_whenMakingReservation_thenThrowException()
		public virtual void givenNotAvailableBook_whenMakingReservation_thenThrowException()
		{
			//given
			BookReservationCommand reservationCommand = ReservationTestData.anyBookReservationCommand(100L, 100L);
			ActiveUser activeUser = ReservationTestData.anyActiveUser(reservationCommand.UserId);

			database.activeUsers[activeUser.IdAsLong] = activeUser;

			assertThrows(typeof(AvailableBookNotFoundExeption), () => facade.handle(reservationCommand));
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Try to reserve book, but active user is not found") public void givenNotActiveUser_whenMakingReservation_thenThrowException()
		public virtual void givenNotActiveUser_whenMakingReservation_thenThrowException()
		{
			//given
			BookReservationCommand reservationCommand = ReservationTestData.anyBookReservationCommand(100L, 100L);
			AvailableBook availableBook = ReservationTestData.anyAvailableBook(reservationCommand.BookId);

			database.availableBooks[availableBook.IdAsLong] = availableBook;

			//when & then
			assertThrows(typeof(ActiveUserNotFoundException), () => facade.handle(reservationCommand));
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Cancel reservation after 3 days") public void givenBookIsReserved_when3daysPass_thenBookIsAvailable()
		public virtual void givenBookIsReserved_when3daysPass_thenBookIsAvailable()
		{
			//given
			ReservedBook reservedBook = ReservationTestData.anyReservedBook(100L, 100L);
			changeReservationTimeFor(reservedBook, Instant.now().minus(4, ChronoUnit.DAYS));
			database.reservedBooks[100L] = reservedBook;

			//when
			facade.cancelOverdueReservations();

			//then
			assertEquals(0, database.reservedBooks.Count);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Do not cancel reservation after 2 days") public void givenBookIsReserved_when2daysPass_thenBookIsStillReserved()
		public virtual void givenBookIsReserved_when2daysPass_thenBookIsStillReserved()
		{
			//given
			ReservedBook reservedBook = ReservationTestData.anyReservedBook(100L, 100L);
			changeReservationTimeFor(reservedBook, Instant.now().minus(2, ChronoUnit.DAYS));
			database.reservedBooks[100L] = reservedBook;

			//when
			facade.cancelOverdueReservations();

			//then
			assertEquals(1, database.reservedBooks.Count);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Successfully borrow a book") public void givenReservedBookAndActiveUser_whenBorrowing_thenBookIsBorrowed()
		public virtual void givenReservedBookAndActiveUser_whenBorrowing_thenBookIsBorrowed()
		{
			//given
			BorrowBookCommand borrowBookCommand = BorrowTestData.anyBorrowBookCommand(100L, 100L);
			ReservedBook reservedBook = BorrowTestData.anyReservedBook(borrowBookCommand.BookId, borrowBookCommand.UserId);
			ActiveUser activeUser = BorrowTestData.anyActiveUser(borrowBookCommand.UserId);

			database.activeUsers[activeUser.IdAsLong] = activeUser;
			database.reservedBooks[reservedBook.IdAsLong] = reservedBook;

			//when
			facade.handle(borrowBookCommand);

			//then
			assertEquals(1, activeUser.BorrowedBookList.Count);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Successful give back a book") public void givenUserWithBorrowedBook_whenBookIsReturned_thenBookIsAvailable()
		public virtual void givenUserWithBorrowedBook_whenBookIsReturned_thenBookIsAvailable()
		{
			//given
			GiveBackBookCommand giveBackBookCommand = BorrowTestData.anyGiveBookCommand(100L, 100L);
			BorrowedBook borrowedBook = BorrowTestData.anyBorrowedBook(giveBackBookCommand.BookId, giveBackBookCommand.UserId);
			ActiveUser activeUser = BorrowTestData.anyActiveUserWithBorrowedBooks(giveBackBookCommand.UserId, new List<BorrowedBook> {borrowedBook});

			database.borrowedBooks[borrowedBook.IdAsLong] = borrowedBook;
			database.activeUsers[activeUser.IdAsLong] = activeUser;

			//when
			facade.handle(giveBackBookCommand);

			//then
			assertEquals(0, database.borrowedBooks.Count);
			assertEquals(1, database.availableBooks.Count);

//====================================================================================================
//End of the allowed output for the Free Edition of Java to C# Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================
