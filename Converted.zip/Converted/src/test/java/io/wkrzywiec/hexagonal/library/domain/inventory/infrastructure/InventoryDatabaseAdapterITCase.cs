﻿namespace io.wkrzywiec.hexagonal.library.domain.inventory.infrastructure
{
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using Book = io.wkrzywiec.hexagonal.library.domain.inventory.core.model.Book;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using Autowired = org.springframework.beans.factory.annotation.Autowired;
	using SpringBootTest = org.springframework.boot.test.context.SpringBootTest;
	using JdbcTemplate = org.springframework.jdbc.core.JdbcTemplate;
	using Sql = org.springframework.test.context.jdbc.Sql;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @SpringBootTest public class InventoryDatabaseAdapterITCase
	public class InventoryDatabaseAdapterITCase
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private BookRepository bookRepository;
		private BookRepository bookRepository;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Autowired private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
		private JdbcTemplate jdbcTemplate;

		private InventoryDatabaseAdapter database;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new InventoryDatabaseAdapter(bookRepository);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Save new book in database") @Sql(scripts = "/clean-database.sql", executionPhase = AFTER_TEST_METHOD) public void givenBook_whenSaveIt_thenBookIsSaved()
		public virtual void givenBook_whenSaveIt_thenBookIsSaved()
		{
			//given
			Book homoDeusBook = BookTestData.homoDeusBook();

			//when
			Book savedBook = database.save(homoDeusBook);

			//then
			long? savedBookId = jdbcTemplate.queryForObject("SELECT id FROM book WHERE id = ?", typeof(Long), savedBook.IdAsLong);

			assertEquals(savedBook.IdAsLong, savedBookId);
		}
	}

}