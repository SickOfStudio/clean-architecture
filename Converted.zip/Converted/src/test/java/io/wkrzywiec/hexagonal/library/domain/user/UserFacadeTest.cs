﻿namespace io.wkrzywiec.hexagonal.library.domain.user
{
	using UserTestData = io.wkrzywiec.hexagonal.library.UserTestData;
	using UserFacade = io.wkrzywiec.hexagonal.library.domain.user.core.UserFacade;
	using AddUserCommand = io.wkrzywiec.hexagonal.library.domain.user.core.model.AddUserCommand;
	using EmailAddress = io.wkrzywiec.hexagonal.library.domain.user.core.model.EmailAddress;
	using User = io.wkrzywiec.hexagonal.library.domain.user.core.model.User;
	using UserIdentifier = io.wkrzywiec.hexagonal.library.domain.user.core.model.UserIdentifier;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;

	public class UserFacadeTest
	{

		private InMemoryUserDatabase database;
		private UserFacade facade;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			database = new InMemoryUserDatabase();
			facade = new UserFacade(database);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Add new user") public void shouldAddNewUser()
		public virtual void shouldAddNewUser()
		{
			//given
			User expectedUser = new User(new EmailAddress(UserTestData.johnDoeEmail()), "John", "Doe");

			AddUserCommand addUserCommand = AddUserCommand.builder().email(UserTestData.johnDoeEmail()).firstName("John").lastName("Doe").build();

			//when
			UserIdentifier userIdentifier = facade.handle(addUserCommand);

			//then
			assertTrue(userIdentifier.AsLong > 0);
			assertEquals(expectedUser, database.users[userIdentifier.AsLong]);
		}
	}

}