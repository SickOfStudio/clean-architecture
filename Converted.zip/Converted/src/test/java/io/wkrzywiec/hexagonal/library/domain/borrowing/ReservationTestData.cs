﻿using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BookReservationCommand = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BookReservationCommand;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;

	public class ReservationTestData
	{

		public static BookReservationCommand anyBookReservationCommand(long? bookId, long? userId)
		{
			return BookReservationCommand.builder().bookId(bookId).userId(userId).build();
		}

		public static ReservedBook anyReservedBook(long? bookId, long? userId)
		{
			return new ReservedBook(bookId, userId);
		}

		public static AvailableBook anyAvailableBook(long? bookId)
		{
			return new AvailableBook(bookId);
		}

		public static ActiveUser anyActiveUser(long? userId)
		{
			return new ActiveUser(userId, new List<ReservedBook>(), new List<BorrowedBook>());
		}
	}

}