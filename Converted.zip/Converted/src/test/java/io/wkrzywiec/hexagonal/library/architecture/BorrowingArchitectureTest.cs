﻿namespace io.wkrzywiec.hexagonal.library.architecture
{
	using ImportOption = com.tngtech.archunit.core.importer.ImportOption;
	using AnalyzeClasses = com.tngtech.archunit.junit.AnalyzeClasses;
	using ArchTest = com.tngtech.archunit.junit.ArchTest;
	using ArchRule = com.tngtech.archunit.lang.ArchRule;
	using BorrowingFacade = io.wkrzywiec.hexagonal.library.domain.borrowing.core.BorrowingFacade;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClass;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.library.Architectures.onionArchitecture;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AnalyzeClasses(packages = {"io.wkrzywiec.hexagonal.library.domain.borrowing"}, importOptions = { ImportOption.DoNotIncludeTests.class }) public class BorrowingArchitectureTest
	public class BorrowingArchitectureTest
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule hexagonalArchInBorrowingDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.borrowing.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.borrowing..").applicationServices("io.wkrzywiec.hexagonal.library.domain.borrowing.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure..");
		public static readonly ArchRule hexagonalArchInBorrowingDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.borrowing.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.borrowing..").applicationServices("io.wkrzywiec.hexagonal.library.domain.borrowing.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.borrowing.infrastructure..");

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule noSpringDependenciesInBorrowingFacade = noClass(io.wkrzywiec.hexagonal.library.domain.borrowing.core.BorrowingFacade.class).should().dependOnClassesThat().resideInAPackage("org.springframework..");
		public static readonly ArchRule noSpringDependenciesInBorrowingFacade = noClass(typeof(BorrowingFacade)).should().dependOnClassesThat().resideInAPackage("org.springframework..");
	}

}