﻿namespace io.wkrzywiec.hexagonal.library.query
{
	using JsonObject = com.google.gson.JsonObject;
	using JsonParser = com.google.gson.JsonParser;
	using BookTestData = io.wkrzywiec.hexagonal.library.BookTestData;
	using BeforeEach = org.junit.jupiter.api.BeforeEach;
	using DisplayName = org.junit.jupiter.api.DisplayName;
	using Test = org.junit.jupiter.api.Test;
	using MediaType = org.springframework.http.MediaType;
	using MockRestServiceServer = org.springframework.test.web.client.MockRestServiceServer;
	using RestTemplate = org.springframework.web.client.RestTemplate;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertEquals;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.junit.jupiter.api.Assertions.assertTrue;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

	public class GoogleBookSearchClientITCase
	{

		private GoogleBookSearchClient client;
		private RestTemplate restTemplate;
		private MockRestServiceServer server;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @BeforeEach public void init()
		public virtual void init()
		{
			restTemplate = new RestTemplate();
			server = MockRestServiceServer.createServer(restTemplate);
			client = new GoogleBookSearchClient(restTemplate);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Search for a book") public void whenSearchForBooks_thenGetListOfBooks()
		public virtual void whenSearchForBooks_thenGetListOfBooks()
		{
			//given
			string harryPotterSearchResponse = BookTestData.harryPotterSearchResponse();
			server.expect(requestTo("https://www.googleapis.com/books/v1/volumes?langRestrict=en&maxResults=40&printType=books&q=" + "harry%20potter")).andRespond(withSuccess(harryPotterSearchResponse, MediaType.APPLICATION_JSON));

			string responseString = client.searchForBooks("harry potter");
			JsonObject response = JsonParser.parseString(responseString).AsJsonObject;
			assertTrue(response.getAsJsonArray("items").size() == 4);
		}

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @Test @DisplayName("Search for a book and get empty result") public void whenSearchForBooks_thenGetEmptyResult()
		public virtual void whenSearchForBooks_thenGetEmptyResult()
		{
			//given
			string noBooksResponse = BookTestData.noBooksSearchResponse();
			server.expect(requestTo("https://www.googleapis.com/books/v1/volumes?langRestrict=en&maxResults=40&printType=books&q=" + "djfjbasdknl")).andRespond(withSuccess(noBooksResponse, MediaType.APPLICATION_JSON));

			//when
			string responseString = client.searchForBooks("djfjbasdknl");
			JsonObject response = JsonParser.parseString(responseString).AsJsonObject;

			//then
			assertEquals(0, response.get("totalItems").AsLong);
		}
	}

}