﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace io.wkrzywiec.hexagonal.library.domain.borrowing
{
	using ActiveUser = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ActiveUser;
	using AvailableBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.AvailableBook;
	using BorrowedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.BorrowedBook;
	using DueDate = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.DueDate;
	using OverdueReservation = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.OverdueReservation;
	using ReservationDetails = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationDetails;
	using ReservationId = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservationId;
	using ReservedBook = io.wkrzywiec.hexagonal.library.domain.borrowing.core.model.ReservedBook;
	using BorrowingDatabase = io.wkrzywiec.hexagonal.library.domain.borrowing.core.ports.outgoing.BorrowingDatabase;


	public class InMemoryBorrowingDatabase : BorrowingDatabase
	{

		internal ConcurrentDictionary<long, ActiveUser> activeUsers = new ConcurrentDictionary<long, ActiveUser>();
		internal ConcurrentDictionary<long, AvailableBook> availableBooks = new ConcurrentDictionary<long, AvailableBook>();
		internal ConcurrentDictionary<long, ReservedBook> reservedBooks = new ConcurrentDictionary<long, ReservedBook>();
		internal ConcurrentDictionary<long, BorrowedBook> borrowedBooks = new ConcurrentDictionary<long, BorrowedBook>();

		public virtual void save(AvailableBook availableBook)
		{
			availableBooks[availableBook.IdAsLong] = availableBook;
			reservedBooks.Remove(availableBook.IdAsLong);
			borrowedBooks.Remove(availableBook.IdAsLong);
		}

		public virtual Optional<AvailableBook> getAvailableBook(long? bookId)
		{
			if (availableBooks.ContainsKey(bookId))
			{
				return availableBooks[bookId];
			}
			else
			{
				return null;
			}
		}

		public virtual Optional<ActiveUser> getActiveUser(long? userId)
		{
			if (activeUsers.ContainsKey(userId))
			{
				return activeUsers[userId];
			}
			else
			{
				return null;
			}
		}

		public virtual ReservationDetails save(ReservedBook reservedBook)
		{
			long? reservationId = (new Random()).nextLong();
			availableBooks.Remove(reservedBook.IdAsLong);
			reservedBooks[reservationId] = reservedBook;
			return new ReservationDetails(new ReservationId(reservationId), reservedBook);
		}

		public virtual void save(BorrowedBook borrowedBook)
		{
			reservedBooks.Remove(borrowedBook.IdAsLong);
			borrowedBooks[borrowedBook.IdAsLong] = borrowedBook;
		}

		public virtual IList<OverdueReservation> findReservationsForMoreThan(long? days)
		{
			return reservedBooks.Values.Where(reservedBook => Instant.now().isAfter(reservedBook.ReservedDateAsInstant.plus(days, ChronoUnit.DAYS))).Select(reservedBook => new OverdueReservation(1L, reservedBook.IdAsLong)).ToList();
		}

		public virtual Optional<ReservedBook> getReservedBook(long? bookId)
		{
			return reservedBooks[bookId];
		}

		public virtual Optional<BorrowedBook> getBorrowedBook(long? bookId)
		{
			return borrowedBooks[bookId];
		}
	}

}