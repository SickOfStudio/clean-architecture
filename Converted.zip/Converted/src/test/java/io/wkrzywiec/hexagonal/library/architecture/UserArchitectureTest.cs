﻿namespace io.wkrzywiec.hexagonal.library.architecture
{
	using ImportOption = com.tngtech.archunit.core.importer.ImportOption;
	using AnalyzeClasses = com.tngtech.archunit.junit.AnalyzeClasses;
	using ArchTest = com.tngtech.archunit.junit.ArchTest;
	using ArchRule = com.tngtech.archunit.lang.ArchRule;
	using UserFacade = io.wkrzywiec.hexagonal.library.domain.user.core.UserFacade;

//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClass;
//JAVA TO C# CONVERTER TODO TASK: This Java 'import static' statement cannot be converted to C#:
//	import static com.tngtech.archunit.library.Architectures.onionArchitecture;

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @AnalyzeClasses(packages = {"io.wkrzywiec.hexagonal.library.domain.user"}, importOptions = { ImportOption.DoNotIncludeTests.class }) public class UserArchitectureTest
	public class UserArchitectureTest
	{
//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule hexagonalArchInUserDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.user.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.user..").applicationServices("io.wkrzywiec.hexagonal.library.domain.user.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.user.infrastructure..");
		public static readonly ArchRule hexagonalArchInUserDomain = onionArchitecture().domainModels("io.wkrzywiec.hexagonal.library.domain.user.core.model..").domainServices("io.wkrzywiec.hexagonal.library.domain.user..").applicationServices("io.wkrzywiec.hexagonal.library.domain.user.application..").adapter("infrastructure", "io.wkrzywiec.hexagonal.library.domain.user.infrastructure..");

//JAVA TO C# CONVERTER TODO TASK: Most Java annotations will not have direct .NET equivalent attributes:
//ORIGINAL LINE: @ArchTest public static final com.tngtech.archunit.lang.ArchRule noSpringDependenciesInUserFacade = noClass(io.wkrzywiec.hexagonal.library.domain.user.core.UserFacade.class).should().dependOnClassesThat().resideInAPackage("org.springframework..");
		public static readonly ArchRule noSpringDependenciesInUserFacade = noClass(typeof(UserFacade)).should().dependOnClassesThat().resideInAPackage("org.springframework..");
	}

}